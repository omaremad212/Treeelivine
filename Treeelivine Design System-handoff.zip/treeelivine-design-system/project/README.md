# Treeelivine Design System

> A design system for **Treeelivine ERP** — an internal operations platform with a client portal, built for marketing agencies running in the Arabic-speaking market.

This system supplies the tokens, type ramp, components, and UI-kit recreations a designer or agent needs to make on-brand artifacts: in-product screens, marketing pages, client-portal flows, slides, and one-off mocks.

---

## What is Treeelivine?

Treeelivine is an internal **ERP for a marketing agency**, plus a **client-facing portal**. It replaces the scattered WhatsApp + Sheets + ad-hoc folder workflow with a single, opinionated tool of record for:

- **CRM** — prospects → qualified → active → lost pipeline, with bulk actions, dedupe, and account-manager scoping.
- **Projects** — `subscription` and `onetime` project shapes, with templates, briefs, workflow stages (manual or sequential), and assigned team members.
- **Briefs** — questionnaire attached to a project; threaded comments; states from `not_started` → `approved`.
- **Tasks** — daily execution of work, with explicit assignee handover, review states, blocking flags, per-task pricing snapshots, and an `efficiencyScore` on completion.
- **Team** — employees with skills, specializations, industry preferences, availability, on-leave flags, and linked user accounts.
- **Finance** — invoices, expenses, recurring salaries, multi-currency snapshots (every record captures original currency, exchange rate, and base-currency equivalent), and print-ready invoice PDFs from the browser.
- **Templates** — reusable workflows, project shells, brief questionnaires, and assignment rules with weights (specialty, industry, availability, workload).
- **Settings** — central control for company identity, languages, currencies, exchange rates, roles, permissions, per-user overrides, and an audit trail.
- **Client Portal** — clients see only their own projects, briefs, and invoices; they can fill the brief, save drafts, submit, and comment.

Default base currency is **SAR**. The UI is **Arabic-first** with full **English** support and **Light/Dark** themes.

### Roles at a glance

| Role | What they touch |
|---|---|
| `admin` | Everything; only role that can edit task pricing directly. |
| `manager` | Operational lead over CRM, projects, tasks. |
| `team.account_manager` | CRM + projects + tasks + brief + team (scoped to their customers). |
| `team.task_member` | Dashboard + projects + tasks + brief only. |
| `finance` | All finance; can review pricing across tasks. |
| `viewer` | Read-only on specific modules. |
| `client` | Portal: only their own projects, briefs, invoices. |

---

## Source materials

This system was built from the SRS document the user provided (reverse-engineered from `frontend/src` + `backend/server.js` + `backend/models`), and the (currently empty) GitHub repo:

- **GitHub:** [omaremad212/Treeelivine](https://github.com/omaremad212/Treeelivine) — at the time of this build the repo contained only the default Next.js scaffold README, so all visual decisions in this system are derived from the SRS, the brand name, and conventions for Arabic-first B2B agency tools. **If you have access to the actual frontend code, explore it for the latest pixel truth** — and feed it back into this design system.

---

## Index

| File / folder | What's in it |
|---|---|
| `README.md` | This file — brand context, content + visual foundations, iconography. |
| `colors_and_type.css` | All design tokens: color (light + dark), type, spacing, radius, shadow. The source of truth — import this into anything. |
| `fonts/` | Web font files (IBM Plex Sans Arabic, IBM Plex Sans, IBM Plex Mono). |
| `assets/` | Logo lockups, brand marks, icons, illustrations. |
| `preview/` | Design-system cards rendered as small HTML files (registered as review assets — see the Design System tab). |
| `ui_kits/erp/` | High-fidelity recreation of the internal ERP UI — dashboard, CRM, projects, tasks, finance. Open `ui_kits/erp/index.html`. |
| `ui_kits/portal/` | Client portal — overview, projects list, brief, invoices. Open `ui_kits/portal/index.html`. |
| `SKILL.md` | Cross-compatible Agent Skill manifest — use this if you load the design system into Claude Code. |

### Where to start

- **Need a token?** Read `colors_and_type.css`. Every color, type ramp, radius, shadow, and motion timing lives there.
- **Need to recreate a component?** Look in `preview/` — every primitive (button, input, badge, KPI, table row, drawer fragment, avatar) is rendered there as a tiny HTML snippet.
- **Need a whole screen?** Look in `ui_kits/erp/` or `ui_kits/portal/` — copy the JSX patterns and the layout grid out of the kits.
- **Need a logo or motif?** `assets/` holds the mark + lockups (both Latin and Arabic wordmarks).
- **Need to flag a substitution?** Search `README.md` for "Substitution flag" — currently called out for the icon family.

### Known substitutions

- **Icons:** the project shipped no proprietary icon set, so Lucide is documented as the default. If a Treeelivine icon family exists, drop it in `assets/icons/` and update the Iconography section.
- **Wordmark:** the "treeelivine" wordmark in `assets/logo-lockup.svg` is set in IBM Plex Sans, not a custom typeface. Replace if the brand has a true wordmark.

---

## Content fundamentals

Treeelivine is **Arabic-first, professional, and operationally direct**. Copy is written for working operators — account managers, finance leads, team members — not for a marketing audience. It avoids hype.

### Voice

- **Operational, not aspirational.** "نظام تشغيل موحد للوكالة" / "Unified ops center for your agency" — describe the job, not the dream.
- **Direct and concrete.** Speak in nouns the user already uses: عميل, مشروع, مهمة, بريف, فاتورة, راتب — not invented brand jargon.
- **Calm authority.** No exclamation marks. No emoji. No second-person hype. Imperative for actions ("إنشاء مهمة" / "Create task"), plain noun for sections ("المشاريع" / "Projects").
- **Bilingual at the seam.** Internal modules name themselves both ways; the SRS itself toggles freely between Arabic concept names and English technical terms (`workflow`, `handover`, `assignment_rule`). The product copy does the same — Arabic for human-facing language, English for technical states and field names.

### Person & tone

- Internal ERP: **third-person, system-of-record voice**. "تم تسليم المهمة" / "Task handed over." Not "You handed it over."
- Empty states: **factual and a little dry**, with one clear action. e.g. "لا يوجد عملاء بعد — أنشئ أول عميل" / "No customers yet — Create your first customer."
- Errors: state the problem, name the field, suggest the fix in one line. "البريد مستخدم — جرّب تسجيل دخول" / "Email already in use — try signing in instead."
- Client portal: **slightly warmer, second-person allowed.** "مشاريعك" / "Your projects". Still no emoji. Still no exclamation.

### Casing & punctuation

- Arabic: sentence case (Arabic doesn't have case). No trailing dots in UI labels or buttons.
- English labels: **Title Case for buttons and primary nav, Sentence case for body and helper text.**
- Acronyms stay uppercase: `CRM`, `KPI`, `PDF`, `SAR`, `JWT`. `ERP` is treated as a noun.
- Currency: always include the code — `1,250.00 SAR`, never just `1250`. Tabular figures everywhere (`font-feature-settings: "tnum"`).
- Dates: Arabic locale dates in Arabic UI (`28 أبريل 2026`), ISO-style `2026-04-28` in compact tables and tooltips.

### Status copy — canonical strings

These appear as badges/pills. Use the exact wording.

| Module | State | AR | EN |
|---|---|---|---|
| Customer | prospect | محتمل | Prospect |
| Customer | qualified | مؤهل | Qualified |
| Customer | active | نشط | Active |
| Customer | suspended | موقوف | Suspended |
| Customer | lost | مفقود | Lost |
| Project | draft | مسودة | Draft |
| Project | active | قيد التنفيذ | In progress |
| Project | on_hold | معلق | On hold |
| Project | completed | منجز | Completed |
| Task | new | جديدة | New |
| Task | in_progress | قيد العمل | In progress |
| Task | ready_for_handover | جاهزة للتسليم | Ready for handover |
| Task | under_review | قيد المراجعة | Under review |
| Task | completed | منجزة | Completed |
| Invoice | unpaid | غير مدفوعة | Unpaid |
| Invoice | partially_paid | مدفوعة جزئيًا | Partial |
| Invoice | paid | مدفوعة | Paid |
| Invoice | overdue | متأخرة | Overdue |
| Brief | not_started | لم تبدأ | Not started |
| Brief | submitted | مُرسلة | Submitted |
| Brief | approved | معتمدة | Approved |

### What we never do

- **No emoji.** Not in copy, not in empty states, not in toasts.
- **No marketing slop.** No "Unlock your agency's potential." No "10x your workflow."
- **No exclamation marks** anywhere in product UI.
- **No filler illustrations** of generic-people-in-an-office. If we show imagery, it's an actual screenshot, an icon, or the brand mark.

---

## Visual foundations

### Brand DNA

**Treeelivine** = tree + olive + vine. The visual language is rooted in that:

- **Olive green** as the primary brand color — a deep, slightly muted `#4f6831` that reads as serious and grown-up, not "tech bro."
- **Warm sand** for surfaces in light mode — `#faf7f1` cream rather than pure white. Reduces eye strain in dense ERP tables and pairs naturally with Arabic type, which carries more visual weight than Latin.
- **Terracotta clay** as the single accent — used sparingly for highlights, never as a primary action.
- **Charcoal-olive** for dark mode — backgrounds bias warm-dark (`#14140f`), not blue-black.

This is **B2B operations software**, not consumer. The aesthetic is closer to Linear or Notion than to Stripe — restrained, functional, with confidence coming from typography and rhythm rather than gradients or color.

### Color

See [`colors_and_type.css`](./colors_and_type.css) for the full token set. Highlights:

- **Brand olive** — 50→900 ramp. Primary actions = `--brand-olive-600`.
- **Clay accent** — used for highlights, charts, the secondary brand mark. Never the CTA color.
- **Sand neutrals** — warm grays, never cool. `--brand-sand-50` is the app background in light mode.
- **Semantic** — `success` (green, distinct from brand), `warning` (mustard, not orange), `danger` (oxide red), `info` (slate blue). All have 50/100/500/600/700 stops.
- **Pipeline tints** — one muted background per CRM column (prospect, qualified, negotiation, active, inactive, lost) so the kanban reads at a glance without flooding with color.
- **Status pills** — every common state has a paired `*-fg` + `*-bg` token. The bg is always ~6% opacity / `*-50`, the fg is `*-700`. No bright pills.

### Type

- **Arabic:** IBM Plex Sans Arabic (Regular, Medium, SemiBold, Bold).
- **Latin:** IBM Plex Sans (matching weights).
- **Mono:** IBM Plex Mono — used in code, IDs, invoice numbers, exchange-rate snapshots.
- The font stack on `[dir="rtl"]` puts the Arabic family first; on `[dir="ltr"]` the Latin family is first. Both share visual DNA so bilingual lines (e.g. `5,200 SAR · مشروع جديد`) stay coherent.
- Base UI size is **14px** — ERP-dense but readable. Marketing surfaces step up to 16–18px body.
- Tabular figures (`font-feature-settings: "tnum"`) everywhere a number lives in a column.

### Spacing & layout

- 4px grid. Tokens: `--space-1`..`--space-24`.
- Internal density is **medium-tight**: table rows are 44px, side nav items are 36px, drawer padding is 24px.
- Sidebar width is **248px** fixed. Top bar is **56px**. Drawer width is **460px**. Max content width on marketing pages is **1440px**.
- **RTL is first-class.** Use logical properties (`padding-inline`, `margin-inline`, `inset-inline-start`) — never `left`/`right`. The full system works on `dir="rtl"` without override.

### Radii

- `--radius-md: 8px` — inputs, buttons, pills.
- `--radius-lg: 12px` — cards.
- `--radius-xl: 16px` — modals, drawers.
- `--radius-pill: 999px` — status badges, avatar borders.
- Never use square (0px) corners — even keyboard keys round to `radius-xs: 3px`.

### Elevation & cards

Treeelivine is a **low-elevation, border-led** system. Cards rest on the surface; they don't float.

- Cards: 1px `--border-2` + `--shadow-xs` (a single bottom hairline). Internal grouping uses `--border-1` dividers, not nested boxes.
- Drawers and modals: `--shadow-lg`, with `--bg-overlay` (45% black) behind.
- Toasts and floating menus: `--shadow-md`.
- **No glassmorphism.** No backdrop-filter blur in product UI. (One exception: the topbar may use `backdrop-filter: saturate(180%) blur(8px)` when scrolled, and only then.)

### Borders

- Default divider: `--border-1` (low-contrast hairline).
- Card/table border: `--border-2`.
- Input border: `--border-3`; focused input swaps to `--border-focus` + `--ring-focus`.
- We never use a colored left-border-accent on a rounded card. That's a tell of generic dashboard slop and is banned.

### Backgrounds

- **No full-bleed photography in product UI.** Marketing landing may use a single hero photograph (warm-toned, natural light, olive-grove or studio imagery — not stock-office-workers).
- **No repeating patterns or textures.** The brand is clean.
- **One subtle motif** is allowed: a low-contrast olive-leaf vector in the corner of empty states and hero panels. Render at ~6% opacity, sized 240–400px, positioned to feel incidental rather than decorative.
- Dashboards use plain `--bg-app` (sand in light, charcoal-olive in dark). Cards sit on `--bg-surface`.

### Motion

- Easing: `--ease-out` (most things), `--ease-spring` (only for the brief "appearing" of a new task card or a kanban drop).
- Durations: 120ms (hover, focus), 180ms (drawer open, dropdown), 260ms (modal, page transitions).
- **No bounce on hover. No scale-up on hover.** Hover is opacity / background only.
- Page transitions: **fade only**. No slide, no scale.
- Charts and KPI numbers can count-up on first reveal — only once per page load, max 400ms.

### Hover / press / focus / disabled

- **Hover:** background tints toward `--bg-hover` (6% olive) or `--bg-active`. Text buttons gain underline. Never resize, never elevate.
- **Press:** background steps to `--bg-active` (12% olive). Primary buttons step to `--brand-primary-active`. No scale-down.
- **Focus:** always a 3px outer ring (`--ring-focus`). Never rely on color alone — the ring is mandatory for accessibility, and Arabic UIs especially need clear keyboard affordance for RTL nav.
- **Disabled:** 45% opacity + `cursor: not-allowed`. No bespoke disabled colors.

### Transparency & blur

- **Transparency** is used for: hover/active tints (~6–14%), the modal overlay (45% black), and the optional leaf motif in empty states.
- **Blur is forbidden** in product UI except a single backdrop blur on the topbar when scrolled past the page header.

### Image treatment

When photographs are used (marketing, settings → company logo, employee avatars):
- **Warm and natural.** Daylight, slightly desaturated, leaning amber/olive rather than blue.
- **No B&W.** No heavy grain.
- Avatars are always **circles**, fall back to a 2-initial monogram on `--brand-olive-100` with `--brand-olive-700` text.
- Company logos appear inside a 1px `--border-2` square at 8px radius — never freestanding.

### Layout rules

- The ERP shell is **fixed sidebar + fixed topbar + scrollable content**. Sidebar collapses to 56px icon-only at narrow widths.
- Drawers slide in from the **inline-end** edge (right in LTR, left in RTL) — never from the bottom on desktop.
- Tables have a fixed header row when scrolling.
- Forms inside drawers use a single column. Forms on full-page settings use a two-column read layout (label left, controls right) — flips correctly in RTL via logical properties.
- Modals are **560px** for confirms, **720px** for create flows, **920px** for split-pane editors.

### Density modes

ERP supports an optional **compact density** toggle (in user preferences). It scales row height to 36px and font size to 13px, but does not change tokens — only the table-specific scale.

---

## Iconography

Treeelivine has no proprietary icon set. **We standardize on [Lucide](https://lucide.dev/)** — a clean, 24px, 2px-stroke, line-icon family that pairs cleanly with IBM Plex.

### Why Lucide

- Open-source, MIT-licensed.
- Stroke weight (1.75–2px) matches Plex's medium weight visually.
- Comprehensive coverage of finance, ops, CRM, calendar, and document concepts the SRS demands.
- Loads tiny via CDN and supports tree-shaking when copied locally.

> **Substitution flag:** the user did not provide a proprietary icon set, so this is a chosen default rather than a brand-mandated one. If a Treeelivine icon family exists, drop it in `assets/icons/` and update this section.

### Usage rules

- **Stroke 1.75px** at 20px and 24px sizes. Drop to 1.5px at 16px.
- **No filled icons.** All icons are line. (Exception: tiny indicator dots and the brand mark itself.)
- **Color** inherits from `currentColor`. Inline an icon to take on the surrounding text color.
- **Pair with labels.** Icon-only buttons must have a tooltip. The CRM, projects, and tasks rails always show icon + label except in collapsed sidebar mode.
- **Size scale:** 14px (compact buttons, status dots), 16px (default inline), 20px (sidebar nav), 24px (page headers, empty states).

### Where icons are loaded from

In any HTML in this system, include Lucide from CDN:

```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<script>lucide.createIcons();</script>
```

For React, use `lucide-react` (or copy specific SVGs into `assets/icons/` and reference them directly).

### Emoji & unicode

- **No emoji.** Anywhere. Not in copy, not as bullets, not as status indicators.
- **No unicode pictographs** (`◉`, `★`, etc.) as substitutes for icons. Use Lucide.
- Currency symbols (`SAR`, `$`, `€`) are allowed inline — they're text, not pictographs.
- Arithmetic operators in formulas (`×`, `÷`, `−`) use the proper unicode characters, not letters.

### Logo

- `assets/logo-mark.svg` — square mark (olive branch + T stem). Use at 24px–80px.
- `assets/logo-lockup.svg` — mark + Latin wordmark for headers and signatures.
- `assets/logo-lockup-ar.svg` — mark + Arabic wordmark.
- Color is `currentColor` — the SVGs inherit. Default to `--brand-olive-600` in light, `--brand-olive-300` in dark.
- Minimum clearspace around the mark = the height of the leaf. Don't crowd it.

