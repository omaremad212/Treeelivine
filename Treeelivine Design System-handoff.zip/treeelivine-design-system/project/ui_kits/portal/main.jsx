/* eslint-disable */
// Treeelivine Client Portal — UI kit
const { useState, useEffect, createContext, useContext, useMemo } = React;

/* -------- Icons (subset) -------- */
const I = (paths, viewBox = "0 0 24 24") => ({ size = 16, color = "currentColor", style, className = "lucide" } = {}) =>
  React.createElement("svg", {
    width: size, height: size, viewBox, fill: "none", stroke: color, strokeWidth: 1.75,
    strokeLinecap: "round", strokeLinejoin: "round", className, style
  }, ...paths.map((d, i) => React.createElement("path", { d, key: i })));

const Icon = {
  Folder: I(["M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"]),
  File:   I(["M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z", "M14 2v6h6"]),
  Wallet: I(["M21 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-1", "M16 12h6", "M16 12a2 2 0 1 0 0 4h6v-4z"]),
  Download: I(["M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", "M7 10l5 5 5-5", "M12 15V3"]),
  Eye: I(["M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z", "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"]),
  ChevronRight: I(["M9 18l6-6-6-6"]),
  Globe: I(["M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z", "M2 12h20", "M12 2a15 15 0 0 1 0 20", "M12 2a15 15 0 0 0 0 20"]),
  Moon: I(["M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"]),
  Sun: I(["M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10z", "M12 1v2", "M12 21v2", "M4.22 4.22l1.42 1.42", "M18.36 18.36l1.42 1.42", "M1 12h2", "M21 12h2", "M4.22 19.78l1.42-1.42", "M18.36 5.64l1.42-1.42"]),
  Bell: I(["M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9", "M13.73 21a2 2 0 0 1-3.46 0"]),
};

/* -------- App context -------- */
const Ctx = createContext({});
function useApp() { return useContext(Ctx); }
function AppProvider({ children }) {
  const [lang, setLang] = useState("ar");
  const [theme, setTheme] = useState("light");
  const [route, setRoute] = useState("dashboard");
  useEffect(() => {
    document.documentElement.setAttribute("dir", lang === "ar" ? "rtl" : "ltr");
    document.documentElement.setAttribute("lang", lang);
    document.documentElement.setAttribute("data-theme", theme);
  }, [lang, theme]);
  const t = (ar, en) => lang === "ar" ? ar : en;
  return React.createElement(Ctx.Provider,
    { value: { lang, setLang, theme, setTheme, route, setRoute, t } }, children);
}

/* -------- Status pill -------- */
const pillStyles = {
  active:    { bg: "var(--status-active-bg)", fg: "var(--status-active-fg)" },
  reviewing: { bg: "var(--status-info-bg)",   fg: "var(--status-info-fg)" },
  approved:  { bg: "var(--status-active-bg)", fg: "var(--status-active-fg)" },
  submitted: { bg: "var(--status-info-bg)",   fg: "var(--status-info-fg)" },
  draft:     { bg: "var(--status-draft-bg)",  fg: "var(--status-draft-fg)" },
  paid:      { bg: "var(--status-active-bg)", fg: "var(--status-active-fg)" },
  issued:    { bg: "var(--status-info-bg)",   fg: "var(--status-info-fg)" },
  partial:   { bg: "var(--status-pending-bg)",fg: "var(--status-pending-fg)" },
  overdue:   { bg: "var(--status-blocked-bg)",fg: "var(--status-blocked-fg)" },
  on_hold:   { bg: "var(--status-pending-bg)",fg: "var(--status-pending-fg)" },
  not_started:{ bg: "var(--status-draft-bg)", fg: "var(--status-draft-fg)" },
};
function Pill({ value, label }) {
  const s = pillStyles[value] || pillStyles.draft;
  return React.createElement("span", { className: "pill", style: { background: s.bg, color: s.fg } },
    React.createElement("span", { className: "dot" }),
    label
  );
}

/* -------- Sample data for the client's portal view -------- */
const CLIENT = {
  ar: "شركة نجد للأزياء", en: "Najd Fashion Co.",
  contact: "Hisham Q.", code: "C-2026-021",
};
const PROJECTS = [
  { id: "p1", code: "PRJ-2026-018", name_ar: "تحديث الهوية البصرية", name_en: "Brand refresh", type: "onetime",     statusAr: "قيد التنفيذ", statusEn: "In progress", statusVal: "active",  brief: { val: "submitted", ar: "مُرسلة", en: "Submitted" }, duration: "12 weeks", started: "12 Mar 2026", desc_ar: "مراجعة شاملة لهوية شركة نجد · لوجو، خط عربي، وأنظمة لون لقنوات سوشيال + متجر.", desc_en: "End-to-end refresh of Najd's identity — logo, Arabic typeface, color systems for social + retail." },
  { id: "p2", code: "PRJ-2026-035", name_ar: "تصوير منتجات صيف 2026", name_en: "Summer 2026 product shoot", type: "onetime", statusAr: "مسودة", statusEn: "Draft", statusVal: "draft", brief: { val: "not_started", ar: "لم تبدأ", en: "Not started" }, duration: "3 weeks", started: "—", desc_ar: "جلسة تصوير 24 قطعة من تشكيلة الصيف داخل الاستوديو.", desc_en: "Studio shoot · 24 SKUs from the summer collection." },
];
const INVOICES = [
  { id: "i1", number: "INV-2026-04-0184", project_ar: "تحديث الهوية", project_en: "Brand refresh", issued: "12 Apr 2026", due: "26 Apr 2026", total: 9200,  currency: "SAR", status: "overdue", statusAr: "متأخرة", statusEn: "Overdue" },
  { id: "i2", number: "INV-2026-03-0162", project_ar: "تحديث الهوية", project_en: "Brand refresh", issued: "28 Feb 2026", due: "14 Mar 2026", total: 4800,  currency: "SAR", status: "paid",    statusAr: "مدفوعة", statusEn: "Paid" },
  { id: "i3", number: "INV-2026-02-0103", project_ar: "تحديث الهوية", project_en: "Brand refresh", issued: "1 Feb 2026",   due: "15 Feb 2026", total: 6400,  currency: "SAR", status: "paid",    statusAr: "مدفوعة", statusEn: "Paid" },
];

/* -------- Top bar -------- */
function Topbar() {
  const { lang, setLang, theme, setTheme, route, setRoute, t } = useApp();
  const nav = [
    { id: "dashboard", ar: "اللوحة",   en: "Overview" },
    { id: "projects",  ar: "مشاريعي", en: "Projects" },
    { id: "brief",     ar: "البريف",   en: "Brief" },
    { id: "invoices",  ar: "الفواتير", en: "Invoices" },
  ];
  return React.createElement("header", { className: "p-topbar" },
    React.createElement("div", { className: "brand" },
      React.createElement("svg", { width: 28, height: 28, viewBox: "0 0 64 64", fill: "currentColor" },
        React.createElement("path", { d: "M32 12 C 32 28, 32 44, 32 56", stroke: "currentColor", strokeWidth: 3.5, strokeLinecap: "round", fill: "none" }),
        React.createElement("path", { d: "M32 22 C 24 21, 16 17, 12 11 C 18 12, 26 16, 32 22 Z" }),
        React.createElement("path", { d: "M32 30 C 40 30, 48 27, 52 21 C 46 22, 38 25, 32 30 Z" }),
        React.createElement("path", { d: "M32 40 C 26 41, 20 39, 16 34 C 21 35, 27 36, 32 40 Z" }),
        React.createElement("ellipse", { cx: 36, cy: 48, rx: 3.2, ry: 4.2, transform: "rotate(20 36 48)" })
      ),
      React.createElement("span", { className: "brand-name" }, "treeelivine")
    ),
    React.createElement("div", { className: "divider" }),
    React.createElement("div", { className: "client" },
      t("بوابة العميل", "Client portal"),
      React.createElement("strong", null, lang === "ar" ? CLIENT.ar : CLIENT.en)
    ),

    React.createElement("nav", { className: "p-nav", style: { marginInlineStart: 32 } },
      ...nav.map(n =>
        React.createElement("button", { key: n.id, className: route === n.id ? "active" : "", onClick: () => setRoute(n.id) },
          lang === "ar" ? n.ar : n.en
        )
      )
    ),

    React.createElement("div", { className: "p-right" },
      React.createElement("button", { className: "p-iconbtn", onClick: () => setLang(lang === "ar" ? "en" : "ar"), title: "Toggle language" },
        React.createElement(Icon.Globe, { size: 16 }),
        React.createElement("span", { style: { fontSize: 11, fontWeight: 500, marginInlineStart: 4 } }, lang === "ar" ? "EN" : "AR")
      ),
      React.createElement("button", { className: "p-iconbtn", onClick: () => setTheme(theme === "light" ? "dark" : "light") },
        React.createElement(theme === "light" ? Icon.Moon : Icon.Sun, { size: 16 })
      ),
      React.createElement("button", { className: "p-iconbtn", title: "Notifications" },
        React.createElement(Icon.Bell, { size: 16 })
      ),
      React.createElement("div", { className: "av", style: { marginInlineStart: 6 } }, lang === "ar" ? "هق" : "HQ")
    )
  );
}

/* -------- Dashboard / Overview -------- */
function Dashboard() {
  const { t, lang, setRoute } = useApp();
  return React.createElement("div", { className: "p-content" },
    React.createElement("div", { className: "p-hero" },
      React.createElement("svg", { className: "leaf", viewBox: "0 0 200 120", fill: "currentColor" },
        React.createElement("path", { d: "M 20 80 C 60 20, 140 30, 180 70 C 130 65, 90 70, 60 95 C 50 90, 35 88, 20 80 Z" }),
        React.createElement("path", { d: "M 30 80 C 70 50, 120 55, 170 75", fill: "none", stroke: "currentColor", strokeWidth: 2 })
      ),
      React.createElement("div", null,
        React.createElement("h1", null, t(`مرحبًا، ${CLIENT.ar}`, `Welcome, ${CLIENT.en}`)),
        React.createElement("div", { className: "sub" },
          t("هذه نظرة موجزة على مشاريعك وفواتيرك وبريفاتك. يمكنك متابعة وتحديث البريف مباشرة من هنا.",
            "A summary of your projects, invoices, and briefs. You can review and update briefs directly from here."))
      ),
      React.createElement("div", { className: "stats" },
        React.createElement("div", { className: "stat" },
          React.createElement("span", { className: "l" }, t("مشاريع نشطة", "Active projects")),
          React.createElement("span", { className: "v" }, "2")),
        React.createElement("div", { className: "stat" },
          React.createElement("span", { className: "l" }, t("غير مدفوع", "Outstanding")),
          React.createElement("span", { className: "v", style: { color: "var(--danger-600)" } }, "9,200",
            React.createElement("span", { style: { fontSize: 12, color: "var(--fg-4)", marginInlineStart: 4, fontWeight: 500 } }, "SAR"))),
        React.createElement("div", { className: "stat" },
          React.createElement("span", { className: "l" }, t("بريف ينتظرك", "Briefs to fill")),
          React.createElement("span", { className: "v" }, "1"))
      )
    ),

    /* Active projects card */
    React.createElement("div", { className: "p-card" },
      React.createElement("div", { className: "p-card-head" },
        React.createElement("h2", null, t("مشاريعك", "Your projects")),
        React.createElement("button", { className: "btn btn-ghost", style: { height: 28, fontSize: 12 }, onClick: () => setRoute("projects") },
          t("عرض الكل", "View all"),
          React.createElement(Icon.ChevronRight, { size: 12, style: { transform: lang === "ar" ? "scaleX(-1)" : "none" } })
        )
      ),
      React.createElement("table", { className: "t-tbl" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            React.createElement("th", null, t("المشروع", "Project")),
            React.createElement("th", null, t("الحالة", "Status")),
            React.createElement("th", null, t("البريف", "Brief")),
            React.createElement("th", null, t("المدة", "Duration"))
          )
        ),
        React.createElement("tbody", null,
          ...PROJECTS.map(p =>
            React.createElement("tr", { key: p.id, onClick: () => setRoute("projects"), style: { cursor: "pointer" } },
              React.createElement("td", null,
                React.createElement("div", { className: "name" }, lang === "ar" ? p.name_ar : p.name_en),
                React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)", marginTop: 2, fontFamily: "var(--font-mono)" } }, p.code)),
              React.createElement("td", null, React.createElement(Pill, { value: p.statusVal, label: lang === "ar" ? p.statusAr : p.statusEn })),
              React.createElement("td", null, React.createElement(Pill, { value: p.brief.val, label: lang === "ar" ? p.brief.ar : p.brief.en })),
              React.createElement("td", { style: { color: "var(--fg-3)", fontSize: 12.5 } }, p.duration)
            )
          )
        )
      )
    ),

    /* Outstanding invoices */
    React.createElement("div", { className: "p-card" },
      React.createElement("div", { className: "p-card-head" },
        React.createElement("h2", null, t("آخر الفواتير", "Recent invoices"))
      ),
      React.createElement("table", { className: "t-tbl" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            React.createElement("th", null, t("رقم الفاتورة", "Number")),
            React.createElement("th", null, t("الإصدار", "Issued")),
            React.createElement("th", null, t("الاستحقاق", "Due")),
            React.createElement("th", null, t("الحالة", "Status")),
            React.createElement("th", { style: { textAlign: "end" } }, t("المبلغ", "Total")),
            React.createElement("th", { style: { width: 60 } })
          )
        ),
        React.createElement("tbody", null,
          ...INVOICES.map(inv =>
            React.createElement("tr", { key: inv.id },
              React.createElement("td", { className: "num", style: { textAlign: "start", color: "var(--fg-1)" } }, inv.number),
              React.createElement("td", { style: { fontSize: 12.5, color: "var(--fg-3)" } }, inv.issued),
              React.createElement("td", { style: { fontSize: 12.5, color: inv.status === "overdue" ? "var(--danger-600)" : "var(--fg-3)" } }, inv.due),
              React.createElement("td", null, React.createElement(Pill, { value: inv.status, label: lang === "ar" ? inv.statusAr : inv.statusEn })),
              React.createElement("td", { className: "num", style: { color: "var(--fg-1)", fontWeight: 500 } }, inv.total.toLocaleString("en-US"), " ", inv.currency),
              React.createElement("td", null,
                React.createElement("div", { style: { display: "flex", gap: 4 } },
                  React.createElement("button", { className: "p-iconbtn", style: { width: 28, height: 28 }, title: "View" }, React.createElement(Icon.Eye, { size: 14 })),
                  React.createElement("button", { className: "p-iconbtn", style: { width: 28, height: 28 }, title: "Download" }, React.createElement(Icon.Download, { size: 14 }))
                )
              )
            )
          )
        )
      )
    )
  );
}

/* -------- Projects list -------- */
function ProjectsList() {
  const { t, lang } = useApp();
  return React.createElement("div", { className: "p-content" },
    React.createElement("div", null,
      React.createElement("h1", { style: { fontSize: 24, fontWeight: 600, color: "var(--fg-1)" } }, t("مشاريعك", "Your projects")),
      React.createElement("div", { style: { fontSize: 14, color: "var(--fg-3)", marginTop: 6 } },
        t("متابعة المشاريع التي تنفذها treeelivine لحسابك.", "Track every project treeelivine is delivering for you."))
    ),
    ...PROJECTS.map(p =>
      React.createElement("div", { key: p.id, className: "p-card", style: { padding: 24 } },
        React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16 } },
          React.createElement("div", null,
            React.createElement("div", { style: { fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-4)" } }, p.code),
            React.createElement("h3", { style: { fontSize: 18, fontWeight: 600, color: "var(--fg-1)", marginTop: 4 } }, lang === "ar" ? p.name_ar : p.name_en),
            React.createElement("p", { style: { fontSize: 13.5, color: "var(--fg-3)", marginTop: 8, maxWidth: 640, lineHeight: 1.55 } }, lang === "ar" ? p.desc_ar : p.desc_en)
          ),
          React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" } },
            React.createElement(Pill, { value: p.statusVal, label: lang === "ar" ? p.statusAr : p.statusEn }),
            React.createElement(Pill, { value: p.brief.val, label: t("بريف · ", "Brief · ") + (lang === "ar" ? p.brief.ar : p.brief.en) })
          )
        ),
        React.createElement("div", { style: { display: "flex", gap: 32, marginTop: 18, paddingTop: 18, borderTop: "1px solid var(--border-1)" } },
          React.createElement("div", null,
            React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)", textTransform: "uppercase", letterSpacing: "0.06em" } }, t("النوع", "Type")),
            React.createElement("div", { style: { fontSize: 13.5, color: "var(--fg-1)", marginTop: 4 } }, t("لمرة واحدة", "One-time"))),
          React.createElement("div", null,
            React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)", textTransform: "uppercase", letterSpacing: "0.06em" } }, t("المدة", "Duration")),
            React.createElement("div", { style: { fontSize: 13.5, color: "var(--fg-1)", marginTop: 4 } }, p.duration)),
          React.createElement("div", null,
            React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)", textTransform: "uppercase", letterSpacing: "0.06em" } }, t("بدأ في", "Started")),
            React.createElement("div", { style: { fontSize: 13.5, color: "var(--fg-1)", marginTop: 4 } }, p.started)),
          React.createElement("div", { style: { marginInlineStart: "auto", display: "flex", gap: 8, alignItems: "center" } },
            React.createElement("button", { className: "btn btn-secondary" }, t("فتح البريف", "Open brief")),
            React.createElement("button", { className: "btn btn-primary" }, t("تفاصيل المشروع", "Project details"))
          )
        )
      )
    )
  );
}

/* -------- Brief page -------- */
function BriefPage() {
  const { t, lang } = useApp();
  const sections = [
    {
      title_ar: "أساسيات العلامة", title_en: "Brand fundamentals",
      help_ar: "هذه الأسئلة تساعدنا نفهم شخصية نجد قبل ما نبدأ نرسم.",
      help_en: "These let us understand Najd's personality before we start designing.",
      qs: [
        { type: "text",     q_ar: "ما الكلمات الثلاث التي تصف نجد؟",                 q_en: "Three words that describe Najd.", a: "أنيقة · هادئة · معاصرة" },
        { type: "textarea", q_ar: "صف العميل المثالي لمتجركم.",                       q_en: "Describe your ideal customer.",     a: "امرأة سعودية بين 28–42، تشتري قطعة دائمة كل موسم، تهتم بالجودة قبل الصيحة." },
        { type: "select",   q_ar: "أي توجه بصري أقرب لنجد؟",                            q_en: "Which visual direction fits Najd?",  a: "هادئ · أرضي" },
      ]
    },
    {
      title_ar: "النطاق والميزانية", title_en: "Scope & budget",
      help_ar: "هذه الإجابات تحدد حدود المشروع.", help_en: "These set the project's bounds.",
      qs: [
        { type: "text", q_ar: "ميزانية المشروع التقديرية", q_en: "Estimated budget", a: "40,000 – 50,000 SAR" },
        { type: "text", q_ar: "الموعد المستهدف للإطلاق",     q_en: "Target launch date", a: "1 يونيو 2026" },
      ]
    }
  ];

  return React.createElement("div", { className: "p-content" },
    React.createElement("div", null,
      React.createElement("div", { style: { fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-4)" } }, "PRJ-2026-018"),
      React.createElement("h1", { style: { fontSize: 24, fontWeight: 600, color: "var(--fg-1)", marginTop: 4 } }, t("بريف · تحديث الهوية البصرية", "Brief · Brand refresh")),
      React.createElement("div", { style: { fontSize: 13.5, color: "var(--fg-3)", marginTop: 6, maxWidth: 640 } },
        t("املأ الإجابات على راحتك — يمكنك حفظ مسودة والعودة لاحقًا. كل تعديل يصل لفريق treeelivine مباشرة.",
          "Fill at your own pace — save a draft and come back. Every edit reaches the treeelivine team in real time."))
    ),

    React.createElement("div", { className: "brief-shell" },
      React.createElement("div", { className: "brief-main" },
        ...sections.map((sec, si) =>
          React.createElement("div", { key: si, className: "p-card brief-section" },
            React.createElement("h3", null, lang === "ar" ? sec.title_ar : sec.title_en),
            React.createElement("div", { className: "help" }, lang === "ar" ? sec.help_ar : sec.help_en),
            ...sec.qs.map((q, qi) =>
              React.createElement("div", { key: qi, className: "brief-q" },
                React.createElement("label", null, lang === "ar" ? q.q_ar : q.q_en),
                q.type === "textarea"
                  ? React.createElement("textarea", { className: "input", rows: 3, defaultValue: q.a })
                  : React.createElement("input", { className: "input", defaultValue: q.a })
              )
            )
          )
        ),

        /* Threaded comments */
        React.createElement("div", { className: "p-card", style: { padding: 22 } },
          React.createElement("h3", { style: { fontSize: 15, fontWeight: 600, color: "var(--fg-1)", marginBottom: 14 } }, t("تعليقات الفريق", "Team comments")),
          React.createElement("div", { className: "comment" },
            React.createElement("div", { className: "av", style: { background: "var(--brand-olive-100)", color: "var(--brand-olive-700)" } }, lang === "ar" ? "أم" : "OM"),
            React.createElement("div", { className: "body" },
              React.createElement("div", { className: "head" },
                React.createElement("span", { className: "who" }, "Omar M."),
                React.createElement("span", { className: "when" }, "26 Apr · 11:30")),
              React.createElement("div", { className: "txt" }, lang === "ar"
                ? "شكرًا — هل ممكن نضيف اقتراحَين لخط عربي قبل أن نقفل البريف؟"
                : "Thanks — can we add two Arabic typeface options before we close the brief?"))
          ),
          React.createElement("div", { className: "comment" },
            React.createElement("div", { className: "av", style: { background: "var(--info-50)", color: "var(--info-700)" } }, lang === "ar" ? "هق" : "HQ"),
            React.createElement("div", { className: "body" },
              React.createElement("div", { className: "head" },
                React.createElement("span", { className: "who" }, "Hisham Q."),
                React.createElement("span", { className: "when" }, "26 Apr · 14:12")),
              React.createElement("div", { className: "txt" }, lang === "ar"
                ? "تمام، نفضّل خط بحروف هندسية لكن غير حادة — قريب من 'IBM Plex Arabic'."
                : "Good idea. We lean toward geometric but not sharp — close to 'IBM Plex Arabic'."))
          ),
          React.createElement("div", { style: { display: "flex", gap: 8, marginTop: 12 } },
            React.createElement("input", { className: "input", placeholder: t("اكتب تعليقًا…", "Write a comment…"), style: { flex: 1 } }),
            React.createElement("button", { className: "btn btn-primary" }, t("إرسال", "Send"))
          )
        )
      ),

      /* Aside */
      React.createElement("aside", { className: "brief-aside" },
        React.createElement("div", { className: "card" },
          React.createElement("h4", null, t("حالة البريف", "Brief status")),
          React.createElement("div", { style: { marginBottom: 14 } }, React.createElement(Pill, { value: "submitted", label: t("مُرسلة · تحت المراجعة", "Submitted · under review") })),
          React.createElement("div", { className: "row" }, React.createElement("span", { className: "l" }, t("تم الإرسال", "Submitted")), React.createElement("span", { className: "v" }, "26 Apr 2026")),
          React.createElement("div", { className: "row" }, React.createElement("span", { className: "l" }, t("آخر تحديث", "Last update")), React.createElement("span", { className: "v" }, "26 Apr · 14:12")),
          React.createElement("div", { className: "row" }, React.createElement("span", { className: "l" }, t("الأسئلة المجابة", "Questions answered")), React.createElement("span", { className: "v" }, "5 / 5"))
        ),
        React.createElement("div", { className: "card" },
          React.createElement("h4", null, t("فريقك من treeelivine", "Your treeelivine team")),
          React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 10, marginTop: 10 } },
            React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
              React.createElement("span", { className: "av" }, lang === "ar" ? "أم" : "OM"),
              React.createElement("div", null,
                React.createElement("div", { style: { fontSize: 13, fontWeight: 500, color: "var(--fg-1)" } }, "Omar Mansour"),
                React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)" } }, t("مدير الحساب", "Account manager")))),
            React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
              React.createElement("span", { className: "av", style: { background: "var(--info-50)", color: "var(--info-700)" } }, lang === "ar" ? "رح" : "RH"),
              React.createElement("div", null,
                React.createElement("div", { style: { fontSize: 13, fontWeight: 500, color: "var(--fg-1)" } }, "Rasha Helmy"),
                React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)" } }, t("مديرة إبداعية", "Creative lead"))))
          )
        ),
        React.createElement("div", { style: { display: "flex", gap: 8 } },
          React.createElement("button", { className: "btn btn-secondary", style: { flex: 1 } }, t("حفظ مسودة", "Save draft")),
          React.createElement("button", { className: "btn btn-primary", style: { flex: 1 } }, t("تحديث الإرسال", "Resubmit"))
        )
      )
    )
  );
}

/* -------- Invoices -------- */
function InvoicesPage() {
  const { t, lang } = useApp();
  return React.createElement("div", { className: "p-content" },
    React.createElement("div", null,
      React.createElement("h1", { style: { fontSize: 24, fontWeight: 600, color: "var(--fg-1)" } }, t("الفواتير", "Invoices")),
      React.createElement("div", { style: { fontSize: 14, color: "var(--fg-3)", marginTop: 6 } },
        t("كل الفواتير المرتبطة بحسابك. اضغط على الفاتورة لفتح ملف PDF.", "All invoices linked to your account. Click to open as PDF."))
    ),

    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 } },
      ...[
        { l: t("مدفوع · إجمالي", "Paid · total"), v: "11,200", tone: "var(--success-600)" },
        { l: t("غير مدفوع", "Outstanding"),       v: "9,200",  tone: "var(--danger-600)" },
        { l: t("الفواتير", "Total invoices"),     v: "3",      tone: "var(--fg-1)" },
      ].map((s, i) =>
        React.createElement("div", { key: i, className: "p-card", style: { padding: "14px 18px", display: "flex", alignItems: "baseline", justifyContent: "space-between" } },
          React.createElement("span", { style: { fontSize: 12, color: "var(--fg-3)", fontWeight: 500 } }, s.l),
          React.createElement("span", { style: { fontSize: 22, fontWeight: 600, color: s.tone, fontFamily: "var(--font-mono)", fontFeatureSettings: '"tnum"' } }, s.v,
            i < 2 ? React.createElement("span", { style: { fontSize: 12, color: "var(--fg-4)", marginInlineStart: 4 } }, "SAR") : null)
        )
      )
    ),

    React.createElement("div", { className: "p-card" },
      React.createElement("table", { className: "t-tbl" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            React.createElement("th", null, t("رقم الفاتورة", "Number")),
            React.createElement("th", null, t("المشروع", "Project")),
            React.createElement("th", null, t("الإصدار", "Issued")),
            React.createElement("th", null, t("الاستحقاق", "Due")),
            React.createElement("th", null, t("الحالة", "Status")),
            React.createElement("th", { style: { textAlign: "end" } }, t("المبلغ", "Total")),
            React.createElement("th", { style: { width: 80 } })
          )
        ),
        React.createElement("tbody", null,
          ...INVOICES.map(inv =>
            React.createElement("tr", { key: inv.id },
              React.createElement("td", { className: "num", style: { textAlign: "start", color: "var(--fg-1)" } }, inv.number),
              React.createElement("td", null, lang === "ar" ? inv.project_ar : inv.project_en),
              React.createElement("td", { style: { fontSize: 12.5, color: "var(--fg-3)" } }, inv.issued),
              React.createElement("td", { style: { fontSize: 12.5, color: inv.status === "overdue" ? "var(--danger-600)" : "var(--fg-3)" } }, inv.due),
              React.createElement("td", null, React.createElement(Pill, { value: inv.status, label: lang === "ar" ? inv.statusAr : inv.statusEn })),
              React.createElement("td", { className: "num", style: { color: "var(--fg-1)", fontWeight: 500 } }, inv.total.toLocaleString("en-US"), " ", inv.currency),
              React.createElement("td", null,
                React.createElement("button", { className: "btn btn-secondary", style: { height: 28, padding: "0 10px", fontSize: 12 } },
                  React.createElement(Icon.Download, { size: 12 }),
                  "PDF")
              )
            )
          )
        )
      )
    )
  );
}

/* -------- App root -------- */
function App() {
  const { route } = useApp();
  return React.createElement("div", { className: "portal-shell" },
    React.createElement(Topbar, null),
    route === "dashboard" ? React.createElement(Dashboard, null) :
    route === "projects"  ? React.createElement(ProjectsList, null) :
    route === "brief"     ? React.createElement(BriefPage, null) :
    route === "invoices"  ? React.createElement(InvoicesPage, null) :
    React.createElement(Dashboard, null)
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  React.createElement(AppProvider, null, React.createElement(App, null))
);
