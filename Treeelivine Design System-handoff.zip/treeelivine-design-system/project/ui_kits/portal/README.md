# UI Kit · Client Portal

The client-facing portal — what `role: "client"` users see. Scoped to a single linked customer.

## What's in here

| File | Role |
|---|---|
| `index.html` | Boots React + Babel and loads `main.jsx`. |
| `app.css` | Imports the design tokens, adds portal-specific layout (top-nav shell, hero card, brief two-column layout). |
| `main.jsx` | Everything else — `<Topbar>`, `<Dashboard>`, `<ProjectsList>`, `<BriefPage>`, `<InvoicesPage>`, the `AppProvider` context, and sample data for one client. |

## Screens

1. **Overview** — welcome hero with 3 stats, a project list, and a recent-invoices table.
2. **Projects** — full list of the customer's projects with description, type, duration, and brief status.
3. **Brief** — a sectioned questionnaire with text/textarea/select questions, a threaded comments thread between the customer and the agency team, and a sidebar showing brief status + the assigned `treeelivine` team members.
4. **Invoices** — paid / outstanding / total KPIs above a list of invoices with a PDF action per row.

## Conventions

- **Single-tenant.** Every view assumes the logged-in customer = "Najd Fashion Co." (sample). Switch the `CLIENT` constant or wire fetches per the SRS section 8.11 (`/portal/projects`, `/portal/briefs/:projectId`, `/portal/invoices`).
- **No CRM, no team, no finance internals.** Per the SRS, the client portal is intentionally small. Don't extend it with operator-only features.
- **Brief is the heart.** This is where the customer collaborates with the agency. The comment thread is a key affordance.

## Verifying

Open `index.html` and click through the four top-nav items. Toggle EN/AR and Light/Dark via the topbar icons.
