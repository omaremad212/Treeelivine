/* eslint-disable */
// Treeelivine ERP — Login screen

function Login({ onSignIn }) {
  const { t, lang, setLang, theme, setTheme } = useApp();

  return React.createElement("div", { style: {
    height: "100vh", display: "grid", gridTemplateColumns: "1fr 1fr",
    background: "var(--bg-app)"
  } },
    /* Left — form */
    React.createElement("div", { style: { display: "flex", flexDirection: "column", padding: "32px 56px", justifyContent: "center" } },
      React.createElement("div", { style: { color: "var(--brand-primary)", display: "flex", alignItems: "center", gap: 10, marginBottom: 48 } },
        React.createElement("svg", { width: 32, height: 32, viewBox: "0 0 64 64", fill: "currentColor" },
          React.createElement("path", { d: "M32 12 C 32 28, 32 44, 32 56", stroke: "currentColor", strokeWidth: 3.5, strokeLinecap: "round", fill: "none" }),
          React.createElement("path", { d: "M32 22 C 24 21, 16 17, 12 11 C 18 12, 26 16, 32 22 Z" }),
          React.createElement("path", { d: "M32 30 C 40 30, 48 27, 52 21 C 46 22, 38 25, 32 30 Z" }),
          React.createElement("path", { d: "M32 40 C 26 41, 20 39, 16 34 C 21 35, 27 36, 32 40 Z" }),
          React.createElement("ellipse", { cx: 36, cy: 48, rx: 3.2, ry: 4.2, transform: "rotate(20 36 48)" })
        ),
        React.createElement("span", { style: { fontSize: 18, fontWeight: 600, color: "var(--fg-1)" } }, "treeelivine")
      ),

      React.createElement("h1", { style: { fontSize: 32, fontWeight: 700, color: "var(--fg-1)", lineHeight: 1.2, letterSpacing: "-0.01em", maxWidth: 380 } },
        t("ادخل لتشغيل الوكالة.", "Sign in to operate the agency.")),
      React.createElement("p", { style: { fontSize: 14, color: "var(--fg-3)", marginTop: 10, maxWidth: 380, lineHeight: 1.55 } },
        t("نظام داخلي للعملاء، المشاريع، المهام، البريف، والمالية. الوصول حسب الدور والصلاحيات الفعلية.",
          "Internal system for customers, projects, tasks, briefs, and finance. Access scoped by role and effective permissions.")),

      React.createElement("form", { style: { marginTop: 36, display: "flex", flexDirection: "column", gap: 14, maxWidth: 380 }, onSubmit: e => { e.preventDefault(); onSignIn(); } },
        React.createElement("label", null,
          React.createElement("div", { style: { fontSize: 12, fontWeight: 500, color: "var(--fg-2)", marginBottom: 6 } }, t("البريد", "Email")),
          React.createElement("input", { className: "input", defaultValue: "sara@treeelivine.sa", style: { width: "100%", height: 38 } })
        ),
        React.createElement("label", null,
          React.createElement("div", { style: { fontSize: 12, fontWeight: 500, color: "var(--fg-2)", marginBottom: 6, display: "flex", justifyContent: "space-between" } },
            React.createElement("span", null, t("كلمة المرور", "Password")),
            React.createElement("a", { href: "#", style: { color: "var(--fg-link)", fontWeight: 400, fontSize: 12 } }, t("نسيتها؟", "Forgot?"))
          ),
          React.createElement("input", { className: "input", type: "password", defaultValue: "••••••••", style: { width: "100%", height: 38 } })
        ),
        React.createElement("label", { style: { display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: "var(--fg-3)" } },
          React.createElement("input", { type: "checkbox", defaultChecked: true }),
          t("ابق مسجلًا لمدة 24 ساعة", "Keep me signed in for 24 hours")
        ),
        React.createElement("button", { type: "submit", className: "btn btn-primary", style: { height: 40, width: "100%", marginTop: 4 } },
          t("ادخل", "Sign in")
        ),
        React.createElement("div", { style: { height: 1, background: "var(--border-1)", margin: "10px 0" } }),
        React.createElement("div", { style: { fontSize: 12, color: "var(--fg-4)", textAlign: "center" } },
          t("عميل جديد؟ ", "New customer? "),
          React.createElement("a", { href: "#", style: { color: "var(--fg-link)", fontWeight: 500 } }, t("سجّل حسابك", "Create an account"))
        )
      ),

      React.createElement("div", { style: { marginTop: "auto", paddingTop: 24, display: "flex", gap: 12, alignItems: "center", color: "var(--fg-4)", fontSize: 11 } },
        React.createElement("button", { className: "btn btn-ghost", style: { height: 26, padding: "0 8px", fontSize: 11 }, onClick: () => setLang(lang === "ar" ? "en" : "ar") },
          React.createElement(Icon.Globe, { size: 12 }),
          lang === "ar" ? "English" : "العربية"
        ),
        React.createElement("button", { className: "btn btn-ghost", style: { height: 26, padding: "0 8px", fontSize: 11 }, onClick: () => setTheme(theme === "light" ? "dark" : "light") },
          React.createElement(theme === "light" ? Icon.Moon : Icon.Sun, { size: 12 }),
          theme === "light" ? t("داكن", "Dark") : t("فاتح", "Light")
        ),
        React.createElement("span", { style: { marginInlineStart: "auto" } }, "© 2026 treeelivine")
      )
    ),

    /* Right — branded panel */
    React.createElement("div", { style: { background: "var(--brand-olive-600)", color: "white", display: "flex", flexDirection: "column", padding: 56, justifyContent: "space-between", position: "relative", overflow: "hidden" } },
      /* Leaf motif */
      React.createElement("svg", { viewBox: "0 0 400 240", style: { position: "absolute", inset: "auto -60px -60px auto", width: 480, opacity: 0.16, color: "white" }, fill: "currentColor" },
        React.createElement("path", { d: "M 40 160 C 120 40, 280 60, 360 140 C 260 130, 180 140, 120 190 C 100 180, 70 176, 40 160 Z" }),
        React.createElement("path", { d: "M 60 160 C 140 100, 240 110, 340 150", fill: "none", stroke: "currentColor", strokeWidth: 3 })
      ),
      React.createElement("div", { style: { position: "relative" } },
        React.createElement("div", { style: { fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", opacity: 0.7, fontWeight: 500 } }, t("في يومٍ واحد", "In a single day")),
        React.createElement("h2", { style: { fontSize: 36, fontWeight: 700, lineHeight: 1.2, marginTop: 16, color: "white" } },
          t("مهمتان جاهزتان للتسليم، فاتورة تم تحصيلها، وعميل جديد في المسار.",
            "Two tasks ready to hand over, an invoice collected, and a new customer in the pipeline."))
      ),
      React.createElement("div", { style: { position: "relative", display: "flex", flexDirection: "column", gap: 14 } },
        React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10, fontSize: 13, opacity: 0.95 } },
          React.createElement("div", { style: { width: 28, height: 28, borderRadius: 99, background: "rgba(255,255,255,0.16)", display: "flex", alignItems: "center", justifyContent: "center" } },
            React.createElement(Icon.Check, { size: 14 })
          ),
          t("صلاحيات حقيقية حسب الدور — وليس فقط مظاهر.", "Real role-based scoping, not just chrome.")
        ),
        React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10, fontSize: 13, opacity: 0.95 } },
          React.createElement("div", { style: { width: 28, height: 28, borderRadius: 99, background: "rgba(255,255,255,0.16)", display: "flex", alignItems: "center", justifyContent: "center" } },
            React.createElement(Icon.Check, { size: 14 })
          ),
          t("لقطات مالية بالعملة الأصلية وسعر الصرف.", "Finance snapshots in original currency + FX.")
        ),
        React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10, fontSize: 13, opacity: 0.95 } },
          React.createElement("div", { style: { width: 28, height: 28, borderRadius: 99, background: "rgba(255,255,255,0.16)", display: "flex", alignItems: "center", justifyContent: "center" } },
            React.createElement(Icon.Check, { size: 14 })
          ),
          t("بوابة عميل ببريف وفواتير — بدون قنوات خارجية.", "Client portal with brief + invoices — no side channels.")
        )
      )
    )
  );
}

window.Login = Login;
