# UI Kit · Treeelivine ERP

Internal operator UI — the agency-side ERP. Recreates the visual + interaction language of the SRS in `Treeelivine ERP/SRS · 2026-04-28`.

## What's in here

| File | Role |
|---|---|
| `index.html` | Boots React + Babel and loads every JSX in order. Open this in a browser. |
| `app.css` | Imports `colors_and_type.css`, then adds layout glue specific to the ERP shell. |
| `Components.jsx` | Shared primitives — `Icon`, `Pill`, `Avatar`, `Button`, status maps, sample data, the `AppProvider` context. Other files reach in via `window.*`. |
| `Shell.jsx` | `<Sidebar>` and `<Topbar>`. |
| `Dashboard.jsx` | Greeting + KPI strip + projects-at-risk table + activity feed + pipeline overview. |
| `CRM.jsx` | Customer table with status filter tabs and the customer detail drawer. |
| `Projects.jsx` | Project card grid with progress + brief + value. |
| `Tasks.jsx` | Kanban board across the five canonical task states. |
| `Finance.jsx` | Invoices list with status filter + finance KPIs. |
| `Login.jsx` | Split-screen sign-in with a brand-color right panel. |
| `main.jsx` | App root, route dispatch, drawer orchestration. |

## Conventions

- **Arabic-first.** The kit boots with `dir="rtl"` and `lang="ar"`. Toggling the `EN` button in the topbar flips both. All layout uses logical properties so it works in either direction without overrides.
- **No real auth or data.** Everything is sample data inside `Components.jsx > DATA`. The "sign in" button just sets a flag. Replace `DATA` with your fetch results to wire this to a backend.
- **One drawer at a time.** The CRM table opens `<CustomerDrawer>` on row click — set `drawer = null` to close. Extend the `App.jsx` route switch to support `project` / `task` drawer kinds.
- **Status pills** are driven by `STATUS` in `Components.jsx`. Add a new state by adding an entry; the tone token picks the color.

## What's left as a stub

The Team, Templates, and Settings routes show a one-line "not drawn" placeholder. They're labeled `Placeholder()` in `main.jsx` and can be implemented by reading the SRS sections 8.7, 8.9, and 8.10 respectively.

## Verifying

Open `index.html` directly in a browser. Use the language and theme toggles in the topbar to flip the UI between Arabic/English and light/dark. Click any nav item or any customer row to exercise the shell.
