/* eslint-disable */
// Treeelivine ERP — Projects screen

function Projects() {
  const { t, lang } = useApp();
  return React.createElement("div", { className: "content" },
    React.createElement("div", { className: "page-head" },
      React.createElement("div", null,
        React.createElement("h1", null, t("المشاريع", "Projects")),
        React.createElement("div", { className: "sub" }, t("الاشتراكات والمشاريع لمرة واحدة، مع البريف والـ workflow.", "Subscriptions and one-time work, with briefs and workflow."))
      ),
      React.createElement("div", { className: "actions" },
        React.createElement(Button, { kind: "secondary", icon: Icon.File }, t("القوالب", "Templates")),
        React.createElement(Button, { kind: "primary", icon: Icon.Plus }, t("مشروع جديد", "New project"))
      )
    ),

    /* Stat strip */
    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 } },
      ...[
        { label: t("نشط", "Active"),       value: 4, tone: "var(--success-600)" },
        { label: t("معلق", "On hold"),     value: 1, tone: "var(--warning-600)" },
        { label: t("مسودة", "Draft"),      value: 1, tone: "var(--fg-3)" },
        { label: t("منجز · 30ي", "Completed · 30d"), value: 3, tone: "var(--brand-primary)" },
      ].map((s, i) =>
        React.createElement("div", { key: i, className: "card-surface", style: { padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" } },
          React.createElement("span", { style: { fontSize: 12, color: "var(--fg-3)", fontWeight: 500 } }, s.label),
          React.createElement("span", { style: { fontSize: 22, fontWeight: 600, color: s.tone, fontFamily: "var(--font-mono)", fontFeatureSettings: '"tnum"' } }, s.value)
        )
      )
    ),

    /* Card grid of projects */
    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14 } },
      ...DATA.projects.map(p =>
        React.createElement("div", { key: p.id, className: "card-surface", style: { padding: 18, display: "flex", flexDirection: "column", gap: 12 } },
          /* Header */
          React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start" } },
            React.createElement("div", null,
              React.createElement("div", { style: { fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-4)" } }, p.code),
              React.createElement("div", { style: { fontSize: 16, fontWeight: 600, color: "var(--fg-1)", marginTop: 4 } }, lang === "ar" ? p.name_ar : p.name_en),
              React.createElement("div", { style: { fontSize: 12.5, color: "var(--fg-3)", marginTop: 2 } }, lang === "ar" ? p.customer_ar : p.customer)
            ),
            React.createElement(Pill, { kind: "project", value: p.status })
          ),

          /* Brief + progress */
          React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 12 } },
            React.createElement("div", { style: { flex: 1 } },
              React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--fg-4)", marginBottom: 4 } },
                React.createElement("span", null, t("التقدّم", "Progress")),
                React.createElement("span", { style: { fontFamily: "var(--font-mono)", color: "var(--fg-2)" } }, p.progress + "%")
              ),
              React.createElement("div", { style: { width: "100%", height: 6, background: "var(--bg-surface-2)", borderRadius: 99, overflow: "hidden" } },
                React.createElement("div", { style: { width: p.progress + "%", height: "100%", background: p.status === "completed" ? "var(--success-500)" : "var(--brand-primary)" } })
              )
            )
          ),

          /* Footer row */
          React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 12, borderTop: "1px solid var(--border-1)" } },
            React.createElement("div", { style: { display: "flex", gap: 12, fontSize: 12, color: "var(--fg-3)" } },
              React.createElement("span", null, React.createElement("span", { style: { color: "var(--fg-1)", fontWeight: 500 } }, p.team), " ", t("أعضاء", "team")),
              React.createElement("span", null, React.createElement("span", { style: { color: "var(--fg-1)", fontWeight: 500 } }, p.tasksOpen), " ", t("مهام", "open")),
              p.tasksOverdue > 0 ? React.createElement("span", { style: { color: "var(--danger-600)", fontWeight: 500 } }, p.tasksOverdue, " ", t("متأخرة", "overdue")) : null,
              React.createElement("span", null, React.createElement(Pill, { kind: "brief", value: p.brief }))
            ),
            React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
              React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--fg-1)" } }, p.value.toLocaleString("en-US"), " SAR"),
              React.createElement(Avatar, { name: p.owner, size: "sm", tint: p.ownerTint })
            )
          )
        )
      )
    )
  );
}

window.Projects = Projects;
