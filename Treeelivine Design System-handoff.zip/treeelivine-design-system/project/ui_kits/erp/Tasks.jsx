/* eslint-disable */
// Treeelivine ERP — Tasks kanban screen

function Tasks() {
  const { t, lang } = useApp();
  const cols = [
    { key: "new",                label: t("جديدة", "New") },
    { key: "in_progress",        label: t("قيد العمل", "In progress") },
    { key: "ready_for_handover", label: t("جاهزة للتسليم", "Ready for handover") },
    { key: "under_review",       label: t("قيد المراجعة", "Under review") },
    { key: "completed",          label: t("منجزة", "Completed") },
  ];

  const priorityDot = (p) => ({
    high:   "var(--danger-500)",
    medium: "var(--warning-500)",
    low:    "var(--success-500)",
  })[p];

  return React.createElement("div", { className: "content" },
    React.createElement("div", { className: "page-head" },
      React.createElement("div", null,
        React.createElement("h1", null, t("المهام", "Tasks")),
        React.createElement("div", { className: "sub" }, t("تشغيل التنفيذ اليومي مع تسليم صريح بين الأعضاء.", "Daily execution with explicit handover between members."))
      ),
      React.createElement("div", { className: "actions" },
        React.createElement(Button, { kind: "secondary", icon: Icon.Filter }, t("تصفية", "Filter")),
        React.createElement(Button, { kind: "primary", icon: Icon.Plus }, t("مهمة جديدة", "New task"))
      )
    ),

    /* Toolbar */
    React.createElement("div", { style: { display: "flex", gap: 8, alignItems: "center" } },
      React.createElement("div", { className: "input", style: { display: "inline-flex", alignItems: "center", gap: 8, width: 280, height: 32 } },
        React.createElement(Icon.Search, { size: 14, color: "var(--fg-4)" }),
        React.createElement("input", { placeholder: t("ابحث في المهام…", "Search tasks…"), style: { background: "transparent", border: "none", outline: "none", flex: 1, color: "var(--fg-1)" } })
      ),
      React.createElement("div", { style: { display: "inline-flex", gap: 6, marginInlineStart: 8 } },
        React.createElement("button", { className: "btn btn-secondary", style: { height: 32, padding: "0 10px", fontSize: 12 } }, t("كل المشاريع", "All projects")),
        React.createElement("button", { className: "btn btn-secondary", style: { height: 32, padding: "0 10px", fontSize: 12 } }, t("كل الأولويات", "All priorities"))
      ),
      React.createElement("div", { style: { marginInlineStart: "auto", display: "inline-flex", border: "1px solid var(--border-3)", borderRadius: 8, overflow: "hidden" } },
        React.createElement("button", { className: "btn btn-ghost", style: { height: 32, padding: "0 12px", fontSize: 12, borderRadius: 0, background: "var(--bg-selected)", color: "var(--brand-primary)" } }, t("Kanban", "Kanban")),
        React.createElement("button", { className: "btn btn-ghost", style: { height: 32, padding: "0 12px", fontSize: 12, borderRadius: 0 } }, t("جدول", "Table"))
      )
    ),

    /* Kanban */
    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10, alignItems: "start" } },
      ...cols.map(col => {
        const tasks = DATA.tasksByStage[col.key] || [];
        return React.createElement("div", { key: col.key, style: { background: "var(--bg-surface-2)", border: "1px solid var(--border-1)", borderRadius: 10, padding: 10, display: "flex", flexDirection: "column", gap: 8, minHeight: 360 } },
          React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "2px 4px" } },
            React.createElement("div", { style: { display: "flex", gap: 8, alignItems: "center" } },
              React.createElement(Pill, { kind: "task", value: col.key })
            ),
            React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-4)" } }, tasks.length)
          ),
          ...tasks.map(tsk =>
            React.createElement("div", { key: tsk.id, style: { background: "var(--bg-surface)", border: "1px solid var(--border-2)", borderRadius: 8, padding: "10px 12px", display: "flex", flexDirection: "column", gap: 8, cursor: "pointer", boxShadow: "var(--shadow-xs)" } },
              React.createElement("div", { style: { display: "flex", alignItems: "flex-start", gap: 8 } },
                React.createElement("div", { style: { width: 6, height: 6, borderRadius: 99, background: priorityDot(tsk.priority), marginTop: 6, flex: "none" } }),
                React.createElement("div", { style: { fontSize: 13, color: "var(--fg-1)", fontWeight: 500, lineHeight: 1.4 } }, lang === "ar" ? tsk.title_ar : tsk.title_en)
              ),
              React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)", fontFamily: "var(--font-mono)" } }, tsk.project),
              React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } },
                React.createElement("div", { style: { display: "inline-flex", alignItems: "center", gap: 4, fontSize: 11, color: tsk.due === "Today" ? "var(--danger-600)" : "var(--fg-3)" } },
                  React.createElement(Icon.Clock, { size: 12 }),
                  React.createElement("span", null, tsk.due)
                ),
                React.createElement(Avatar, { name: tsk.assignee, size: "sm", tint: tsk.tint })
              )
            )
          ),
          React.createElement("button", { className: "btn btn-ghost", style: { height: 30, fontSize: 12, justifyContent: "flex-start", color: "var(--fg-4)" } },
            React.createElement(Icon.Plus, { size: 12 }),
            t("إضافة", "Add task")
          )
        );
      })
    )
  );
}

window.Tasks = Tasks;
