/* eslint-disable */
// Treeelivine ERP — CRM screen with detail drawer

function CRM() {
  const { t, lang, drawer, setDrawer } = useApp();
  const [filter, setFilter] = React.useState("all");

  const filtered = filter === "all"
    ? DATA.customers
    : DATA.customers.filter(c => c.status === filter);

  const tabs = [
    { key: "all",         label: t("الكل", "All"),               count: DATA.customers.length },
    { key: "prospect",    label: t("محتمل", "Prospect"),         count: 1 },
    { key: "qualified",   label: t("مؤهل", "Qualified"),         count: 1 },
    { key: "negotiation", label: t("تفاوض", "Negotiation"),      count: 1 },
    { key: "active",      label: t("نشط", "Active"),             count: 3 },
    { key: "lost",        label: t("مفقود", "Lost"),             count: 1 },
  ];

  return React.createElement("div", { className: "content" },
    React.createElement("div", { className: "page-head" },
      React.createElement("div", null,
        React.createElement("h1", null, t("العملاء", "Customers")),
        React.createElement("div", { className: "sub" }, t("إدارة الـ CRM ومسار العميل من Prospect إلى Active.", "Manage the CRM pipeline from Prospect to Active."))
      ),
      React.createElement("div", { className: "actions" },
        React.createElement(Button, { kind: "secondary", icon: Icon.Download }, t("تصدير CSV", "Export CSV")),
        React.createElement(Button, { kind: "primary", icon: Icon.Plus }, t("عميل جديد", "New customer"))
      )
    ),

    /* Filter tabs */
    React.createElement("div", { style: { display: "flex", gap: 4, borderBottom: "1px solid var(--border-1)", marginBottom: -16 } },
      ...tabs.map(tab =>
        React.createElement("button", {
          key: tab.key,
          onClick: () => setFilter(tab.key),
          style: {
            padding: "10px 16px", border: "none", background: "transparent",
            color: filter === tab.key ? "var(--fg-1)" : "var(--fg-3)",
            fontSize: 13, fontWeight: 500, cursor: "pointer",
            borderBottom: filter === tab.key ? "2px solid var(--brand-primary)" : "2px solid transparent",
            marginBottom: "-1px",
            display: "inline-flex", alignItems: "center", gap: 8
          }
        }, tab.label,
          React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-4)" } }, tab.count)
        )
      )
    ),

    /* Toolbar */
    React.createElement("div", { style: { display: "flex", gap: 8, alignItems: "center" } },
      React.createElement("div", { className: "input", style: { display: "inline-flex", alignItems: "center", gap: 8, width: 280, height: 34 } },
        React.createElement(Icon.Search, { size: 14, color: "var(--fg-4)" }),
        React.createElement("input", { placeholder: t("ابحث بالاسم، الهاتف، البريد…", "Search by name, phone, email…"), style: { background: "transparent", border: "none", outline: "none", flex: 1, color: "var(--fg-1)" } })
      ),
      React.createElement(Button, { kind: "secondary", icon: Icon.Filter }, t("تصفية", "Filter")),
      React.createElement("div", { style: { marginInlineStart: "auto", fontSize: 12, color: "var(--fg-4)" } }, t(`عرض ${filtered.length} من ${DATA.customers.length}`, `${filtered.length} of ${DATA.customers.length}`))
    ),

    /* Table */
    React.createElement("div", { className: "card-surface", style: { overflow: "hidden" } },
      React.createElement("table", { className: "t-table" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            React.createElement("th", { style: { width: 28 } }, React.createElement("input", { type: "checkbox" })),
            React.createElement("th", null, t("الكود", "Code")),
            React.createElement("th", null, t("الشركة", "Company")),
            React.createElement("th", null, t("الحالة", "Status")),
            React.createElement("th", null, t("الخدمة", "Service")),
            React.createElement("th", null, t("المسؤول", "Owner")),
            React.createElement("th", { style: { textAlign: "end" } }, t("الميزانية", "Budget")),
            React.createElement("th", null, t("متابعة", "Follow-up")),
            React.createElement("th", { style: { width: 28 } })
          )
        ),
        React.createElement("tbody", null,
          ...filtered.map(c =>
            React.createElement("tr", {
              key: c.id,
              onClick: () => setDrawer({ kind: "customer", id: c.id }),
              style: { cursor: "pointer" },
              className: drawer && drawer.id === c.id ? "selected" : ""
            },
              React.createElement("td", { onClick: e => e.stopPropagation() }, React.createElement("input", { type: "checkbox" })),
              React.createElement("td", { className: "num", style: { color: "var(--fg-4)", fontSize: 11.5, textAlign: "start" } }, c.code),
              React.createElement("td", null,
                React.createElement("div", { className: "name" }, lang === "ar" ? c.company_ar : c.company_en),
                React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)", marginTop: 2 } }, c.contact)
              ),
              React.createElement("td", null, React.createElement(Pill, { kind: "customer", value: c.status })),
              React.createElement("td", { style: { color: "var(--fg-3)", fontSize: 12.5 } }, c.service),
              React.createElement("td", null,
                React.createElement("div", { style: { display: "inline-flex", alignItems: "center", gap: 8 } },
                  React.createElement(Avatar, { name: c.owner, size: "sm", tint: c.ownerTint }),
                  React.createElement("span", { style: { fontSize: 12.5 } }, c.owner)
                )
              ),
              React.createElement("td", { className: "num" }, c.budget.toLocaleString("en-US"), " SAR"),
              React.createElement("td", { style: { fontSize: 12.5, color: c.followUp === "—" ? "var(--fg-5)" : "var(--fg-2)" } }, c.followUp),
              React.createElement("td", { onClick: e => e.stopPropagation() },
                React.createElement(Icon.MoreH, { size: 16, color: "var(--fg-4)" })
              )
            )
          )
        )
      )
    )
  );
}

/* ----- Customer detail drawer ----- */
function CustomerDrawer({ id, onClose }) {
  const { t, lang } = useApp();
  const c = DATA.customers.find(x => x.id === id);
  if (!c) return null;

  const fieldsAr = [
    ["الكود", c.code],
    ["جهة التواصل", c.contact],
    ["المصدر", c.source],
    ["الخدمة", c.service],
    ["المسؤول", c.owner],
    ["الأولوية", c.priority],
    ["الميزانية", c.budget.toLocaleString("en-US") + " SAR"],
  ];
  const fieldsEn = [
    ["Code", c.code],
    ["Contact", c.contact],
    ["Source", c.source],
    ["Service", c.service],
    ["Owner", c.owner],
    ["Priority", c.priority],
    ["Budget", c.budget.toLocaleString("en-US") + " SAR"],
  ];
  const fields = lang === "ar" ? fieldsAr : fieldsEn;

  return React.createElement("div", { className: "drawer-scrim", onClick: onClose },
    React.createElement("div", { className: "drawer", onClick: e => e.stopPropagation() },
      React.createElement("div", { className: "drawer-head" },
        React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 } },
          React.createElement("div", null,
            React.createElement("div", { style: { fontSize: 18, fontWeight: 600, color: "var(--fg-1)" } }, lang === "ar" ? c.company_ar : c.company_en),
            React.createElement("div", { style: { fontSize: 12, color: "var(--fg-4)", marginTop: 4, fontFamily: "var(--font-mono)" } }, c.code, " · ", c.contact)
          ),
          React.createElement("button", { onClick: onClose, className: "btn btn-ghost btn-icon" },
            React.createElement(Icon.X, { size: 16 })
          )
        ),
        React.createElement("div", { style: { marginTop: 12, display: "flex", gap: 8 } },
          React.createElement(Pill, { kind: "customer", value: c.status })
        )
      ),

      React.createElement("div", { className: "drawer-body" },
        /* Fields */
        React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px 24px" } },
          ...fields.map(([k, v], i) =>
            React.createElement("div", { key: i },
              React.createElement("div", { className: "field-label" }, k),
              React.createElement("div", { className: "field-value", style: { marginTop: 3 } }, v)
            )
          )
        ),
        React.createElement("hr", { className: "divider" }),

        /* Activity timeline */
        React.createElement("div", null,
          React.createElement("div", { className: "field-label", style: { marginBottom: 10 } }, t("النشاط", "Activity")),
          React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 10 } },
            ...[
              { dt: "26 Apr · 10:42", text: lang === "ar" ? "تم تحديث الميزانية إلى 18,500 SAR" : "Budget updated to 18,500 SAR" },
              { dt: "24 Apr · 14:08", text: lang === "ar" ? "أرسلت مقترح الخدمة" : "Service proposal sent" },
              { dt: "22 Apr",          text: lang === "ar" ? "أضيف العميل من إحالة 'نادي الفروسية'" : "Added via referral from 'Equestrian Club'" },
            ].map((a, i) =>
              React.createElement("div", { key: i, style: { display: "flex", gap: 10 } },
                React.createElement("div", { style: { width: 6, height: 6, borderRadius: 99, background: "var(--brand-primary)", marginTop: 6, flex: "none" } }),
                React.createElement("div", null,
                  React.createElement("div", { style: { fontSize: 13, color: "var(--fg-1)" } }, a.text),
                  React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)", fontFamily: "var(--font-mono)", marginTop: 2 } }, a.dt)
                )
              )
            )
          )
        )
      ),

      React.createElement("div", { className: "drawer-footer" },
        React.createElement(Button, { kind: "ghost" }, t("أرشفة", "Archive")),
        React.createElement(Button, { kind: "secondary", icon: Icon.Send }, t("إرسال بريف", "Send brief")),
        React.createElement(Button, { kind: "primary" }, t("تعديل", "Edit"))
      )
    )
  );
}

window.CRM = CRM;
window.CustomerDrawer = CustomerDrawer;
