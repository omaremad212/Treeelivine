/* eslint-disable */
// Treeelivine ERP — app shell (sidebar + topbar)
const { useState: useStateShell } = React;

function Brand() {
  return React.createElement("div", { className: "brand" },
    React.createElement("svg", { width: 28, height: 28, viewBox: "0 0 64 64", fill: "currentColor" },
      React.createElement("path", { d: "M32 12 C 32 28, 32 44, 32 56", stroke: "currentColor", strokeWidth: 3.5, strokeLinecap: "round", fill: "none" }),
      React.createElement("path", { d: "M32 22 C 24 21, 16 17, 12 11 C 18 12, 26 16, 32 22 Z" }),
      React.createElement("path", { d: "M32 30 C 40 30, 48 27, 52 21 C 46 22, 38 25, 32 30 Z" }),
      React.createElement("path", { d: "M32 40 C 26 41, 20 39, 16 34 C 21 35, 27 36, 32 40 Z" }),
      React.createElement("ellipse", { cx: 36, cy: 48, rx: 3.2, ry: 4.2, transform: "rotate(20 36 48)" })
    ),
    React.createElement("span", { className: "brand-name" }, "treeelivine")
  );
}

function NavItem({ id, icon: IconC, label, count, active, onClick }) {
  return React.createElement("button",
    { className: `nav-item ${active ? "active" : ""}`, onClick: () => onClick(id) },
    React.createElement(IconC, { size: 16 }),
    React.createElement("span", null, label),
    count != null ? React.createElement("span", { className: "count" }, count) : null
  );
}

function Sidebar() {
  const { lang, route, setRoute, t } = useApp();
  const items = [
    { section: t("الرئيسية", "Main") },
    { id: "dashboard", icon: Icon.Dashboard, label: t("اللوحة", "Dashboard") },
    { id: "crm",       icon: Icon.Users,     label: t("العملاء", "CRM"),     count: 34 },
    { id: "projects",  icon: Icon.Folder,    label: t("المشاريع", "Projects"), count: 14 },
    { id: "tasks",     icon: Icon.CheckSquare, label: t("المهام", "Tasks"),  count: 23 },
    { id: "finance",   icon: Icon.Wallet,    label: t("المالية", "Finance") },
    { section: t("الإدارة", "Manage") },
    { id: "team",      icon: Icon.UserCog,   label: t("الفريق", "Team") },
    { id: "templates", icon: Icon.File,      label: t("القوالب", "Templates") },
    { id: "settings",  icon: Icon.Settings,  label: t("الإعدادات", "Settings") },
  ];

  return React.createElement("aside", { className: "sidebar" },
    React.createElement(Brand, null),
    ...items.map((it, i) => it.section
      ? React.createElement("div", { className: "nav-section", key: "s"+i }, it.section)
      : React.createElement(NavItem, { key: it.id, ...it, active: route === it.id, onClick: setRoute })
    ),
    React.createElement("div", { className: "user-block" },
      React.createElement("span", { className: "av" }, lang === "ar" ? "سع" : "SA"),
      React.createElement("div", { className: "meta" },
        React.createElement("div", { className: "name" }, t("سارة العامري", "Sara Al-Amiri")),
        React.createElement("div", { className: "role" }, "account_manager")
      ),
      React.createElement(Icon.LogOut, { size: 14, color: "var(--fg-4)", style: { marginInlineStart: "auto", cursor: "pointer" } })
    )
  );
}

function Topbar({ crumbs }) {
  const { lang, setLang, theme, setTheme, t } = useApp();
  return React.createElement("header", { className: "topbar" },
    React.createElement("div", { className: "crumbs" },
      ...crumbs.map((c, i) => [
        React.createElement("span", { key: "c"+i, className: i === crumbs.length - 1 ? "cur" : "" }, c),
        i < crumbs.length - 1 ? React.createElement(Icon.ChevronRight, { size: 12, color: "var(--fg-5)", key: "s"+i }) : null
      ]).flat()
    ),
    React.createElement("div", { className: "search" },
      React.createElement(Icon.Search, { size: 14 }),
      React.createElement("input", { placeholder: t("ابحث في كل النظام…", "Search across the system…") }),
      React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-5)" } }, "⌘K")
    ),
    React.createElement("div", { className: "right" },
      React.createElement("button", { className: "iconbtn", title: "Toggle language", onClick: () => setLang(lang === "ar" ? "en" : "ar") },
        React.createElement(Icon.Globe, { size: 16 }),
        React.createElement("span", { style: { fontSize: 11, marginInlineStart: 4, fontWeight: 500 } }, lang === "ar" ? "EN" : "AR")
      ),
      React.createElement("button", { className: "iconbtn", title: "Toggle theme", onClick: () => setTheme(theme === "light" ? "dark" : "light") },
        React.createElement(theme === "light" ? Icon.Moon : Icon.Sun, { size: 16 })
      ),
      React.createElement("button", { className: "iconbtn", title: "Notifications" },
        React.createElement(Icon.Bell, { size: 16 })
      ),
      React.createElement("div", { style: { width: 1, height: 24, background: "var(--border-1)", margin: "0 6px" } }),
      React.createElement("span", { className: "av av-md" }, lang === "ar" ? "سع" : "SA")
    )
  );
}

window.Sidebar = Sidebar;
window.Topbar = Topbar;
