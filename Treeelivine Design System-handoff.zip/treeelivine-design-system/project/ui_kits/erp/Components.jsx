/* eslint-disable */
// Treeelivine ERP — shared primitives, icons, status maps, sample data.
// Exposed via window.* for cross-file Babel scopes.

const { useState, useEffect, useMemo, useRef, createContext, useContext, Fragment } = React;

/* ============================================================
   ICONS — small inline subset, Lucide-style 24/2px stroke
   ============================================================ */
const I = (paths, viewBox = "0 0 24 24") => ({ size = 16, color = "currentColor", style, className = "lucide" } = {}) =>
  React.createElement("svg", {
    width: size, height: size, viewBox,
    fill: "none", stroke: color, strokeWidth: 1.75,
    strokeLinecap: "round", strokeLinejoin: "round",
    className, style
  }, ...paths.map((d, i) => React.createElement("path", { d, key: i })));

const Icon = {
  Dashboard: I(["M3 13h8V3H3z", "M13 21h8V11h-8z", "M3 21h8v-6H3z", "M13 9h8V3h-8z"]),
  Users:     I(["M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", "M22 21v-2a4 4 0 0 0-3-3.87", "M16 3.13a4 4 0 0 1 0 7.75"]).bind(null) ||
             I(["M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"]),
  Folder:    I(["M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"]),
  CheckSquare: I(["M9 11l3 3L22 4", "M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"]),
  Wallet:    I(["M21 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-1", "M16 12h6", "M16 12a2 2 0 1 0 0 4h6v-4z"]),
  UserCog:   I(["M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", "M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z", "M19 11l1 2 2 .5-1.5 1.5.5 2-2-1-2 1 .5-2L16 13.5l2-.5z"]),
  Settings:  I(["M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z", "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09c0 .67.39 1.27 1 1.51a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.24.61.84 1 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"]),
  File:      I(["M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z", "M14 2v6h6", "M16 13H8", "M16 17H8", "M10 9H8"]),
  Bell:      I(["M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9", "M13.73 21a2 2 0 0 1-3.46 0"]),
  Search:    I(["M21 21l-4.35-4.35", "M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16z"]),
  Plus:      I(["M12 5v14", "M5 12h14"]),
  ChevronDown: I(["M6 9l6 6 6-6"]),
  ChevronRight: I(["M9 18l6-6-6-6"]),
  ChevronLeft: I(["M15 18l-6-6 6-6"]),
  Filter:    I(["M22 3H2l8 9.46V19l4 2v-8.54z"]),
  Download:  I(["M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", "M7 10l5 5 5-5", "M12 15V3"]),
  X:         I(["M18 6L6 18", "M6 6l12 12"]),
  Calendar:  I(["M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z", "M16 2v4", "M8 2v4", "M3 10h18"]),
  Clock:     I(["M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z", "M12 6v6l4 2"]),
  ArrowUp:   I(["M12 19V5", "M5 12l7-7 7 7"]),
  ArrowDown: I(["M12 5v14", "M19 12l-7 7-7-7"]),
  ArrowRight: I(["M5 12h14", "M12 5l7 7-7 7"]),
  MoreH:     I(["M19 12a1 1 0 1 0 0-2 1 1 0 0 0 0 2z", "M12 12a1 1 0 1 0 0-2 1 1 0 0 0 0 2z", "M5 12a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"]),
  Send:      I(["M22 2L11 13", "M22 2l-7 20-4-9-9-4z"]),
  Eye:       I(["M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z", "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"]),
  Check:     I(["M20 6L9 17l-5-5"]),
  Globe:     I(["M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z", "M2 12h20", "M12 2a15 15 0 0 1 0 20", "M12 2a15 15 0 0 0 0 20"]),
  Sun:       I(["M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10z", "M12 1v2", "M12 21v2", "M4.22 4.22l1.42 1.42", "M18.36 18.36l1.42 1.42", "M1 12h2", "M21 12h2", "M4.22 19.78l1.42-1.42", "M18.36 5.64l1.42-1.42"]),
  Moon:      I(["M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"]),
  Leaf:      I(["M11 20A7 7 0 0 1 4 13V4l6 2 6-2v9a7 7 0 0 1-5 7z", "M11 12v8", "M11 12l-4-4", "M11 12l4-4"]),
  TrendingUp: I(["M22 7l-9.5 9.5-5-5L1 18", "M16 7h6v6"]),
  AlertCircle: I(["M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z", "M12 8v4", "M12 16h.01"]),
  CreditCard: I(["M21 4H3a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z", "M1 10h22"]),
  LogOut:    I(["M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", "M16 17l5-5-5-5", "M21 12H9"]),
  HandIn:    I(["M5 12h14", "M12 5l7 7-7 7"]),
  PlayCircle: I(["M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z", "M10 8l6 4-6 4z"]),
};

/* ============================================================
   STATUS DEFINITIONS
   ============================================================ */
const STATUS = {
  customer: {
    prospect:    { ar: "محتمل",       en: "Prospect",     tone: "info" },
    qualified:   { ar: "مؤهل",        en: "Qualified",    tone: "completed" },
    negotiation: { ar: "تفاوض",       en: "Negotiation",  tone: "pending" },
    active:      { ar: "نشط",         en: "Active",       tone: "active" },
    inactive:    { ar: "غير نشط",     en: "Inactive",     tone: "draft" },
    lost:        { ar: "مفقود",       en: "Lost",         tone: "blocked" },
  },
  project: {
    draft:       { ar: "مسودة",       en: "Draft",        tone: "draft" },
    active:      { ar: "قيد التنفيذ", en: "In progress",  tone: "active" },
    on_hold:     { ar: "معلق",        en: "On hold",      tone: "pending" },
    completed:   { ar: "منجز",        en: "Completed",    tone: "completed" },
    cancelled:   { ar: "ملغي",        en: "Cancelled",    tone: "blocked" },
  },
  task: {
    new:                { ar: "جديدة",          en: "New",                 tone: "info" },
    in_progress:        { ar: "قيد العمل",      en: "In progress",         tone: "pending" },
    ready_for_handover: { ar: "جاهزة للتسليم",  en: "Ready for handover",  tone: "accent" },
    under_review:       { ar: "قيد المراجعة",   en: "Under review",        tone: "info" },
    reopened:           { ar: "أعيد فتحها",     en: "Reopened",            tone: "blocked" },
    completed:          { ar: "منجزة",          en: "Completed",           tone: "active" },
  },
  invoice: {
    draft:           { ar: "مسودة",          en: "Draft",     tone: "draft" },
    issued:          { ar: "صادرة",          en: "Issued",    tone: "info" },
    partially_paid:  { ar: "مدفوعة جزئيًا",  en: "Partial",   tone: "pending" },
    paid:            { ar: "مدفوعة",         en: "Paid",      tone: "active" },
    overdue:         { ar: "متأخرة",         en: "Overdue",   tone: "blocked" },
  },
  brief: {
    not_started:     { ar: "لم تبدأ",     en: "Not started",     tone: "draft" },
    draft:           { ar: "مسودة",       en: "Draft",           tone: "draft" },
    submitted:       { ar: "مُرسلة",      en: "Submitted",       tone: "info" },
    reviewing:       { ar: "تحت المراجعة", en: "Reviewing",       tone: "pending" },
    changes_requested: { ar: "تعديلات مطلوبة", en: "Changes requested", tone: "blocked" },
    approved:        { ar: "معتمدة",      en: "Approved",        tone: "active" },
  },
};

const toneStyle = (tone) => {
  const map = {
    info:      { bg: "var(--status-info-bg)",      fg: "var(--status-info-fg)" },
    completed: { bg: "var(--status-completed-bg)", fg: "var(--status-completed-fg)" },
    active:    { bg: "var(--status-active-bg)",    fg: "var(--status-active-fg)" },
    draft:     { bg: "var(--status-draft-bg)",     fg: "var(--status-draft-fg)" },
    pending:   { bg: "var(--status-pending-bg)",   fg: "var(--status-pending-fg)" },
    blocked:   { bg: "var(--status-blocked-bg)",   fg: "var(--status-blocked-fg)" },
    accent:    { bg: "var(--brand-clay-50)",       fg: "var(--brand-clay-700)" },
  };
  return map[tone] || map.draft;
};

/* ============================================================
   I18N + Theme context
   ============================================================ */
const AppContext = createContext({});

function AppProvider({ children }) {
  const [lang, setLang] = useState("ar");
  const [theme, setTheme] = useState("light");
  const [route, setRoute] = useState("dashboard");
  const [drawer, setDrawer] = useState(null);   // { kind, id }

  useEffect(() => {
    document.documentElement.setAttribute("dir", lang === "ar" ? "rtl" : "ltr");
    document.documentElement.setAttribute("lang", lang);
    document.documentElement.setAttribute("data-theme", theme);
  }, [lang, theme]);

  const t = (ar, en) => (lang === "ar" ? ar : en);

  return React.createElement(AppContext.Provider,
    { value: { lang, setLang, theme, setTheme, route, setRoute, drawer, setDrawer, t } },
    children);
}
const useApp = () => useContext(AppContext);

/* ============================================================
   PRIMITIVES
   ============================================================ */
function Pill({ kind, value, en, ar, tone }) {
  let label = "", t = tone;
  if (kind && value && STATUS[kind] && STATUS[kind][value]) {
    const def = STATUS[kind][value];
    t = def.tone;
    label = useApp().lang === "ar" ? def.ar : def.en;
  } else {
    label = useApp().lang === "ar" ? (ar || en) : (en || ar);
  }
  const s = toneStyle(t);
  return React.createElement("span", { className: "pill", style: { background: s.bg, color: s.fg } },
    React.createElement("span", { className: "dot" }),
    label
  );
}

function Avatar({ name, size = "md", tint = "olive" }) {
  const initials = (name || "?").split(" ").map(s => s[0]).slice(0, 2).join("").toUpperCase();
  const tints = {
    olive: { bg: "var(--brand-olive-100)", fg: "var(--brand-olive-700)" },
    clay:  { bg: "var(--brand-clay-100)",  fg: "var(--brand-clay-700)" },
    info:  { bg: "var(--info-50)",         fg: "var(--info-700)" },
    sand:  { bg: "var(--brand-sand-200)",  fg: "var(--neutral-700)" },
  };
  const t = tints[tint] || tints.olive;
  return React.createElement("span",
    { className: `av av-${size}`, style: { background: t.bg, color: t.fg } },
    initials);
}

function Button({ children, kind = "secondary", icon: IconComp, onClick, style }) {
  return React.createElement("button",
    { className: `btn btn-${kind}`, onClick, style },
    IconComp ? React.createElement(IconComp, { size: 14 }) : null,
    children
  );
}

function IconBtn({ icon: IconComp, onClick, label, style }) {
  return React.createElement("button",
    { className: "btn btn-secondary btn-icon", onClick, "aria-label": label, title: label, style },
    React.createElement(IconComp, { size: 16 })
  );
}

/* ============================================================
   SAMPLE DATA
   ============================================================ */
const DATA = {
  user: { name: "سارة العامري", role: "account_manager", initials: "سع" },

  customers: [
    { id: "c1",  code: "C-2026-018", company_ar: "مؤسسة الواحة للتسويق", company_en: "Oasis Marketing Est.", contact: "Layla Saeed", status: "active", source: "Referral", budget: 18500, owner: "Sara A.", ownerTint: "olive", priority: "high", followUp: "28 Apr", service: "Social media · monthly" },
    { id: "c2",  code: "C-2026-021", company_ar: "شركة نجد للأزياء", company_en: "Najd Fashion Co.", contact: "Hisham Q.", status: "negotiation", source: "Inbound", budget: 42000, owner: "Omar M.", ownerTint: "clay", priority: "high", followUp: "30 Apr", service: "Brand refresh" },
    { id: "c3",  code: "C-2026-024", company_ar: "دار بيان للنشر", company_en: "Bayan Publishing", contact: "Mona F.", status: "qualified", source: "Cold outreach", budget: 12000, owner: "Sara A.", ownerTint: "olive", priority: "medium", followUp: "2 May", service: "Print catalog" },
    { id: "c4",  code: "C-2026-027", company_ar: "نادي الفروسية", company_en: "Equestrian Club", contact: "Khalid R.", status: "active", source: "Repeat", budget: 30000, owner: "Rasha H.", ownerTint: "info", priority: "medium", followUp: "—", service: "Annual report" },
    { id: "c5",  code: "C-2026-031", company_ar: "مطاعم سدير", company_en: "Sudair Restaurants", contact: "Yousef A.", status: "prospect", source: "Event", budget: 8500, owner: "Omar M.", ownerTint: "clay", priority: "low", followUp: "5 May", service: "Menu redesign" },
    { id: "c6",  code: "C-2025-204", company_ar: "أكاديمية رؤى", company_en: "Ruya Academy", contact: "Hana K.", status: "lost", source: "Referral", budget: 6500, owner: "Sara A.", ownerTint: "olive", priority: "low", followUp: "—", service: "Identity refresh" },
    { id: "c7",  code: "C-2026-009", company_ar: "صالون نور", company_en: "Noor Salon", contact: "Reem N.", status: "active", source: "Walk-in", budget: 4200, owner: "Rasha H.", ownerTint: "info", priority: "low", followUp: "—", service: "Social media · monthly" },
  ],

  projects: [
    { id: "p1", code: "PRJ-2026-018", name_ar: "نجد · تحديث الهوية", name_en: "Najd · Brand refresh",      customer: "Najd Fashion Co.", customer_ar: "شركة نجد", type: "onetime",      status: "on_hold",     brief: "submitted", owner: "Omar M.", ownerTint: "clay",  value: 12480, team: 4, tasksOpen: 6, tasksOverdue: 1, progress: 38 },
    { id: "p2", code: "PRJ-2026-024", name_ar: "الواحة · سوشيال أبريل", name_en: "Oasis · April social",     customer: "Oasis Marketing", customer_ar: "مؤسسة الواحة", type: "subscription", status: "active",      brief: "approved",  owner: "Sara A.", ownerTint: "olive", value: 2760,  team: 3, tasksOpen: 4, tasksOverdue: 0, progress: 62 },
    { id: "p3", code: "PRJ-2026-009", name_ar: "بيان · كتالوج مطبوع", name_en: "Bayan · Print catalog",       customer: "Bayan Publishing", customer_ar: "دار بيان", type: "onetime",      status: "active",      brief: "reviewing", owner: "Sara A.", ownerTint: "olive", value: 8400,  team: 2, tasksOpen: 8, tasksOverdue: 2, progress: 22 },
    { id: "p4", code: "PRJ-2025-201", name_ar: "نادي الفروسية · التقرير السنوي", name_en: "Equestrian · Annual report", customer: "Equestrian Club", customer_ar: "نادي الفروسية", type: "onetime", status: "completed", brief: "approved",  owner: "Rasha H.", ownerTint: "info",  value: 22000, team: 5, tasksOpen: 0, tasksOverdue: 0, progress: 100 },
    { id: "p5", code: "PRJ-2026-031", name_ar: "صالون نور · سوشيال", name_en: "Noor · Monthly social",     customer: "Noor Salon", customer_ar: "صالون نور", type: "subscription", status: "active",      brief: "approved",  owner: "Rasha H.", ownerTint: "info",  value: 4200,  team: 2, tasksOpen: 3, tasksOverdue: 0, progress: 78 },
    { id: "p6", code: "PRJ-2026-035", name_ar: "سدير · إعادة تصميم منيو", name_en: "Sudair · Menu redesign",   customer: "Sudair Restaurants", customer_ar: "مطاعم سدير", type: "onetime", status: "draft",       brief: "not_started", owner: "Omar M.", ownerTint: "clay", value: 8500, team: 0, tasksOpen: 0, tasksOverdue: 0, progress: 0 },
  ],

  tasksByStage: {
    new: [
      { id: "t1", title_ar: "تصميم 6 ستوريز رمضانية", title_en: "Design 6 Ramadan stories",     project: "Oasis · April",      assignee: "RH", tint: "info",  due: "30 Apr", priority: "high" },
      { id: "t2", title_ar: "كتابة سكربت إعلان 30 ث", title_en: "Write 30s ad script",            project: "Najd · Brand",       assignee: "OM", tint: "clay",  due: "1 May",  priority: "medium" },
    ],
    in_progress: [
      { id: "t3", title_ar: "تخطيط شبكة سوشيال أبريل", title_en: "Plan April social grid",        project: "Oasis · April",      assignee: "SA", tint: "olive", due: "29 Apr", priority: "high" },
      { id: "t4", title_ar: "اقتراح خط عربي للهوية", title_en: "Arabic typeface proposal",        project: "Najd · Brand",       assignee: "RH", tint: "info",  due: "2 May",  priority: "high" },
      { id: "t5", title_ar: "تصوير منتجات داخل الاستوديو", title_en: "In-studio product shoot",  project: "Bayan · Catalog",    assignee: "OM", tint: "clay",  due: "3 May",  priority: "medium" },
    ],
    ready_for_handover: [
      { id: "t6", title_ar: "موود بورد نهائي", title_en: "Final mood board",                      project: "Najd · Brand",       assignee: "RH", tint: "info",  due: "Today",  priority: "high" },
    ],
    under_review: [
      { id: "t7", title_ar: "نسخة عربية للموقع المصغر", title_en: "Arabic copy · landing",       project: "Equestrian · Annual",assignee: "SA", tint: "olive", due: "Today",  priority: "medium" },
      { id: "t8", title_ar: "تخطيط الغلاف الأمامي", title_en: "Front cover layout",               project: "Bayan · Catalog",    assignee: "OM", tint: "clay",  due: "29 Apr", priority: "high" },
    ],
    completed: [
      { id: "t9",  title_ar: "بريف مكتمل", title_en: "Brief intake completed",                    project: "Oasis · April",      assignee: "SA", tint: "olive", due: "22 Apr", priority: "low" },
      { id: "t10", title_ar: "خطة تشغيل سنوية", title_en: "Annual ops plan",                      project: "Equestrian · Annual",assignee: "RH", tint: "info",  due: "20 Apr", priority: "low" },
    ],
  },

  invoices: [
    { id: "i1", number: "INV-2026-04-0184", customer_ar: "شركة نجد للأزياء", customer_en: "Najd Fashion Co.", project: "Brand refresh", issued: "12 Apr 2026", due: "26 Apr 2026", total: 9200,  currency: "SAR", status: "overdue" },
    { id: "i2", number: "INV-2026-04-0192", customer_ar: "مؤسسة الواحة", customer_en: "Oasis Marketing", project: "April social",  issued: "18 Apr 2026", due: "2 May 2026",  total: 2760,  currency: "SAR", status: "issued" },
    { id: "i3", number: "INV-2026-04-0205", customer_ar: "دار بيان للنشر", customer_en: "Bayan Publishing", project: "Print catalog", issued: "20 Apr 2026", due: "4 May 2026",  total: 8400,  currency: "SAR", status: "partially_paid" },
    { id: "i4", number: "INV-2026-03-0162", customer_ar: "نادي الفروسية", customer_en: "Equestrian Club", project: "Annual report", issued: "28 Mar 2026", due: "11 Apr 2026", total: 22000, currency: "SAR", status: "paid" },
    { id: "i5", number: "INV-2026-04-0211", customer_ar: "صالون نور", customer_en: "Noor Salon",     project: "April social",   issued: "22 Apr 2026", due: "6 May 2026",  total: 4200,  currency: "SAR", status: "issued" },
  ],

  activity: [
    { time: "10:42", user: "Sara A.", tint: "olive", action_ar: "حوّلت مهمة 'موود بورد نهائي' إلى Omar M.", action_en: "handed over 'Final mood board' to Omar M.", project: "Najd · Brand" },
    { time: "10:18", user: "Omar M.", tint: "clay",  action_ar: "أرسل البريف للمراجعة الداخلية", action_en: "submitted brief for internal review", project: "Sudair · Menu" },
    { time: "09:55", user: "Finance",  tint: "sand",  action_ar: "سجّل استلام دفعة جزئية 4,200 SAR", action_en: "recorded partial payment of 4,200 SAR", project: "Bayan · Catalog" },
    { time: "09:31", user: "Rasha H.", tint: "info",  action_ar: "أكملت مهمة 'خطة تشغيل سنوية'", action_en: "completed task 'Annual ops plan'",         project: "Equestrian · Annual" },
    { time: "Yesterday", user: "Sara A.", tint: "olive", action_ar: "أنشأت مشروع 'سدير · إعادة تصميم منيو'", action_en: "created project 'Sudair · Menu redesign'", project: "Sudair · Menu" },
  ],
};

/* Expose everything */
Object.assign(window, {
  Icon, STATUS, toneStyle,
  AppProvider, AppContext, useApp,
  Pill, Avatar, Button, IconBtn,
  DATA,
});
