/* eslint-disable */
// Treeelivine ERP — Dashboard screen

function Dashboard() {
  const { t, lang } = useApp();
  const fmt = (n) => n.toLocaleString("en-US");

  const kpis = [
    { label: t("العملاء النشطون", "Active customers"), value: "34", delta: "+4 ▲", deltaCls: "delta-up", sub: t("آخر 30 يومًا", "vs prev 30d") },
    { label: t("التحصيل · 30ي", "Collected · 30d"),    value: "82,450", unit: "SAR", delta: "+12.4% ▲", deltaCls: "delta-up", sub: t("صافي بعد المرتجعات", "Net of refunds") },
    { label: t("غير مدفوع", "Outstanding"),             value: "18,900", unit: "SAR", delta: "+3 ▲", deltaCls: "delta-down", sub: t("متأخرة 3 فواتير", "3 invoices overdue") },
    { label: t("مهام متأخرة", "Overdue tasks"),         value: "7",    delta: "+2 ▲", deltaCls: "delta-down", sub: t("منذ الإثنين", "Since Monday") },
  ];

  return React.createElement("div", { className: "content" },
    React.createElement("div", { className: "page-head" },
      React.createElement("div", null,
        React.createElement("h1", null, t("صباح الخير، سارة", "Good morning, Sara")),
        React.createElement("div", { className: "sub" }, t("هذا ما يحتاج انتباهك اليوم.", "Here's what needs your attention today."))
      ),
      React.createElement("div", { className: "actions" },
        React.createElement(Button, { kind: "secondary", icon: Icon.Calendar }, t("آخر 30 يوم", "Last 30d")),
        React.createElement(Button, { kind: "primary",   icon: Icon.Plus }, t("مهمة جديدة", "New task"))
      )
    ),

    /* KPIs */
    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 } },
      ...kpis.map((k, i) =>
        React.createElement("div", { className: "card-surface kpi", key: i },
          React.createElement("span", { className: "label" }, k.label),
          React.createElement("span", { className: "value" }, fmt(parseFloat(k.value.replace(/,/g, ""))).toLocaleString("en-US") || k.value,
            k.unit ? React.createElement("span", { className: "unit", style: { marginInlineStart: 6 } }, k.unit) : null),
          React.createElement("span", { className: `delta ${k.deltaCls}` }, k.delta),
          React.createElement("span", { style: { fontSize: 11, color: "var(--fg-4)", marginTop: 2 } }, k.sub)
        )
      )
    ),

    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16 } },
      /* Projects at risk */
      React.createElement("div", { className: "card-surface" },
        React.createElement("div", { style: { padding: "14px 18px", borderBottom: "1px solid var(--border-1)", display: "flex", justifyContent: "space-between", alignItems: "center" } },
          React.createElement("h3", { style: { fontSize: 15, fontWeight: 600, color: "var(--fg-1)" } }, t("مشاريع تحتاج انتباهًا", "Projects needing attention")),
          React.createElement("button", { className: "btn btn-ghost", style: { height: 28, fontSize: 12 } }, t("عرض الكل", "View all"))
        ),
        React.createElement("table", { className: "t-table" },
          React.createElement("thead", null,
            React.createElement("tr", null,
              React.createElement("th", null, t("المشروع", "Project")),
              React.createElement("th", null, t("العميل", "Customer")),
              React.createElement("th", null, t("الحالة", "Status")),
              React.createElement("th", { style: { textAlign: "end" } }, t("متأخرة", "Overdue")),
              React.createElement("th", { style: { textAlign: "end" } }, t("التقدّم", "Progress"))
            )
          ),
          React.createElement("tbody", null,
            ...DATA.projects.filter(p => p.tasksOverdue > 0 || p.status === "on_hold").slice(0, 4).map(p =>
              React.createElement("tr", { key: p.id },
                React.createElement("td", { className: "name" }, lang === "ar" ? p.name_ar : p.name_en),
                React.createElement("td", null, lang === "ar" ? p.customer_ar : p.customer),
                React.createElement("td", null, React.createElement(Pill, { kind: "project", value: p.status })),
                React.createElement("td", { className: "num", style: { color: p.tasksOverdue > 0 ? "var(--danger-600)" : "var(--fg-3)" } }, p.tasksOverdue),
                React.createElement("td", { style: { textAlign: "end" } },
                  React.createElement("div", { style: { display: "inline-flex", alignItems: "center", gap: 8 } },
                    React.createElement("div", { style: { width: 80, height: 5, background: "var(--bg-surface-2)", borderRadius: 99, overflow: "hidden" } },
                      React.createElement("div", { style: { width: p.progress + "%", height: "100%", background: "var(--brand-primary)" } })
                    ),
                    React.createElement("span", { style: { fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-3)", minWidth: 28 } }, p.progress + "%")
                  )
                )
              )
            )
          )
        )
      ),

      /* Activity */
      React.createElement("div", { className: "card-surface", style: { display: "flex", flexDirection: "column" } },
        React.createElement("div", { style: { padding: "14px 18px", borderBottom: "1px solid var(--border-1)" } },
          React.createElement("h3", { style: { fontSize: 15, fontWeight: 600, color: "var(--fg-1)" } }, t("الحركة الأخيرة", "Recent activity"))
        ),
        React.createElement("div", { style: { padding: "8px 18px 14px", display: "flex", flexDirection: "column" } },
          ...DATA.activity.map((a, i) =>
            React.createElement("div", { key: i, style: { padding: "10px 0", borderBottom: i < DATA.activity.length - 1 ? "1px solid var(--border-1)" : "none", display: "flex", gap: 10, alignItems: "flex-start" } },
              React.createElement(Avatar, { name: a.user, size: "sm", tint: a.tint }),
              React.createElement("div", { style: { flex: 1, minWidth: 0 } },
                React.createElement("div", { style: { fontSize: 12.5, color: "var(--fg-1)", lineHeight: 1.45 } },
                  React.createElement("span", { style: { fontWeight: 500 } }, a.user), " ", lang === "ar" ? a.action_ar : a.action_en
                ),
                React.createElement("div", { style: { fontSize: 11, color: "var(--fg-4)", marginTop: 2, fontFamily: "var(--font-mono)" } }, a.time, " · ", a.project)
              )
            )
          )
        )
      )
    ),

    /* Pipeline strip */
    React.createElement("div", { className: "card-surface" },
      React.createElement("div", { style: { padding: "14px 18px", borderBottom: "1px solid var(--border-1)", display: "flex", justifyContent: "space-between", alignItems: "center" } },
        React.createElement("h3", { style: { fontSize: 15, fontWeight: 600, color: "var(--fg-1)" } }, t("خط أنابيب العملاء", "CRM pipeline"))
      ),
      React.createElement("div", { style: { padding: 16, display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8 } },
        ...[
          { key: "prospect",    label: t("محتمل", "Prospect"),       count: 12, bg: "var(--pipeline-prospect)" },
          { key: "qualified",   label: t("مؤهل", "Qualified"),       count: 8,  bg: "var(--pipeline-qualified)" },
          { key: "negotiation", label: t("تفاوض", "Negotiation"),    count: 5,  bg: "var(--pipeline-negotiation)" },
          { key: "active",      label: t("نشط", "Active"),           count: 34, bg: "var(--pipeline-active)" },
          { key: "inactive",    label: t("غير نشط", "Inactive"),     count: 11, bg: "var(--pipeline-inactive)" },
          { key: "lost",        label: t("مفقود", "Lost"),           count: 7,  bg: "var(--pipeline-lost)" },
        ].map(c =>
          React.createElement("div", { key: c.key, style: { borderRadius: 8, padding: "10px 12px", background: c.bg, border: "1px solid var(--border-1)" } },
            React.createElement("div", { style: { fontSize: 11, color: "var(--fg-3)", fontWeight: 500 } }, c.label),
            React.createElement("div", { style: { fontSize: 22, fontWeight: 600, color: "var(--fg-1)", marginTop: 4, fontFamily: "var(--font-mono)", fontFeatureSettings: '"tnum"' } }, c.count)
          )
        )
      )
    )
  );
}

window.Dashboard = Dashboard;
