/* eslint-disable */
// Treeelivine ERP — Finance screen

function Finance() {
  const { t, lang } = useApp();

  return React.createElement("div", { className: "content" },
    React.createElement("div", { className: "page-head" },
      React.createElement("div", null,
        React.createElement("h1", null, t("المالية", "Finance")),
        React.createElement("div", { className: "sub" }, t("الفواتير، المصروفات، الرواتب · العملة الأساسية SAR.", "Invoices, expenses, salaries · base currency SAR."))
      ),
      React.createElement("div", { className: "actions" },
        React.createElement(Button, { kind: "secondary", icon: Icon.Download }, t("تصدير", "Export")),
        React.createElement(Button, { kind: "secondary", icon: Icon.Plus }, t("مصروف", "Expense")),
        React.createElement(Button, { kind: "primary", icon: Icon.Plus }, t("فاتورة جديدة", "New invoice"))
      )
    ),

    /* KPIs */
    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 } },
      ...[
        { label: t("التحصيل · 30ي", "Collected · 30d"), value: "82,450", sub: "+12.4%", tone: "var(--success-600)", up: true },
        { label: t("غير مدفوع", "Outstanding"),         value: "42,360", sub: "5 invoices", tone: "var(--danger-600)", up: false },
        { label: t("المصروفات · 30ي", "Expenses · 30d"), value: "31,180", sub: "+2.1%", tone: "var(--fg-1)", up: false },
        { label: t("الصافي", "Net · 30d"),               value: "51,270", sub: "+18.6%", tone: "var(--brand-primary)", up: true },
      ].map((k, i) =>
        React.createElement("div", { key: i, className: "card-surface kpi" },
          React.createElement("span", { className: "label" }, k.label),
          React.createElement("span", { className: "value" }, k.value,
            React.createElement("span", { className: "unit", style: { marginInlineStart: 6 } }, "SAR")),
          React.createElement("span", { className: "delta", style: { color: k.tone } }, k.up ? "▲ " : "● ", k.sub)
        )
      )
    ),

    /* Invoice list */
    React.createElement("div", { className: "card-surface", style: { overflow: "hidden" } },
      React.createElement("div", { style: { padding: "14px 18px", borderBottom: "1px solid var(--border-1)", display: "flex", justifyContent: "space-between", alignItems: "center" } },
        React.createElement("h3", { style: { fontSize: 15, fontWeight: 600, color: "var(--fg-1)" } }, t("الفواتير", "Invoices")),
        React.createElement("div", { style: { display: "inline-flex", gap: 6 } },
          ...[t("الكل", "All"), t("صادرة", "Issued"), t("متأخرة", "Overdue"), t("مدفوعة", "Paid")].map((lbl, i) =>
            React.createElement("button", {
              key: i,
              className: "btn btn-ghost",
              style: { height: 26, padding: "0 10px", fontSize: 12, background: i === 0 ? "var(--bg-selected)" : "transparent", color: i === 0 ? "var(--brand-primary)" : "var(--fg-3)" }
            }, lbl)
          )
        )
      ),
      React.createElement("table", { className: "t-table" },
        React.createElement("thead", null,
          React.createElement("tr", null,
            React.createElement("th", null, t("رقم", "Number")),
            React.createElement("th", null, t("العميل", "Customer")),
            React.createElement("th", null, t("المشروع", "Project")),
            React.createElement("th", null, t("الإصدار", "Issued")),
            React.createElement("th", null, t("الاستحقاق", "Due")),
            React.createElement("th", null, t("الحالة", "Status")),
            React.createElement("th", { style: { textAlign: "end" } }, t("المبلغ", "Total")),
            React.createElement("th", { style: { width: 60 } })
          )
        ),
        React.createElement("tbody", null,
          ...DATA.invoices.map(inv =>
            React.createElement("tr", { key: inv.id },
              React.createElement("td", { className: "num", style: { textAlign: "start", color: "var(--fg-1)" } }, inv.number),
              React.createElement("td", { className: "name" }, lang === "ar" ? inv.customer_ar : inv.customer_en),
              React.createElement("td", { style: { fontSize: 12.5, color: "var(--fg-3)" } }, inv.project),
              React.createElement("td", { style: { fontSize: 12.5, color: "var(--fg-3)" } }, inv.issued),
              React.createElement("td", { style: { fontSize: 12.5, color: inv.status === "overdue" ? "var(--danger-600)" : "var(--fg-3)" } }, inv.due),
              React.createElement("td", null, React.createElement(Pill, { kind: "invoice", value: inv.status })),
              React.createElement("td", { className: "num", style: { color: "var(--fg-1)", fontWeight: 500 } }, inv.total.toLocaleString("en-US"), " ", inv.currency),
              React.createElement("td", null,
                React.createElement("div", { style: { display: "flex", gap: 4 } },
                  React.createElement("button", { className: "btn btn-ghost btn-icon", style: { width: 28, height: 28 } },
                    React.createElement(Icon.Eye, { size: 14 })
                  ),
                  React.createElement("button", { className: "btn btn-ghost btn-icon", style: { width: 28, height: 28 } },
                    React.createElement(Icon.Download, { size: 14 })
                  )
                )
              )
            )
          )
        )
      )
    )
  );
}

window.Finance = Finance;
