/* eslint-disable */
// Treeelivine ERP — root App component

function App() {
  const [signedIn, setSignedIn] = React.useState(true);  // default to signed-in for kit preview
  const { route, drawer, setDrawer, t } = useApp();

  if (!signedIn) {
    return React.createElement(Login, { onSignIn: () => setSignedIn(true) });
  }

  const screens = {
    dashboard: { node: React.createElement(Dashboard, null), crumbs: [t("الرئيسية", "Home"), t("اللوحة", "Dashboard")] },
    crm:       { node: React.createElement(CRM, null),       crumbs: [t("الرئيسية", "Home"), t("العملاء", "Customers")] },
    projects:  { node: React.createElement(Projects, null),  crumbs: [t("الرئيسية", "Home"), t("المشاريع", "Projects")] },
    tasks:     { node: React.createElement(Tasks, null),     crumbs: [t("الرئيسية", "Home"), t("المهام", "Tasks")] },
    finance:   { node: React.createElement(Finance, null),   crumbs: [t("الرئيسية", "Home"), t("المالية", "Finance")] },
    team:      { node: Placeholder("الفريق", "Team"),         crumbs: [t("الرئيسية", "Home"), t("الفريق", "Team")] },
    templates: { node: Placeholder("القوالب", "Templates"),    crumbs: [t("الرئيسية", "Home"), t("القوالب", "Templates")] },
    settings:  { node: Placeholder("الإعدادات", "Settings"),  crumbs: [t("الرئيسية", "Home"), t("الإعدادات", "Settings")] },
  };

  const cur = screens[route] || screens.dashboard;

  return React.createElement("div", { className: "shell" },
    React.createElement(Sidebar, null),
    React.createElement("div", { className: "main", style: { position: "relative" } },
      React.createElement(Topbar, { crumbs: cur.crumbs }),
      cur.node,
      drawer && drawer.kind === "customer"
        ? React.createElement(CustomerDrawer, { id: drawer.id, onClose: () => setDrawer(null) })
        : null
    )
  );
}

function Placeholder(ar, en) {
  const Comp = function () {
    const { t } = useApp();
    return React.createElement("div", { className: "content" },
      React.createElement("div", { className: "page-head" },
        React.createElement("h1", null, t(ar, en))
      ),
      React.createElement("div", { className: "card-surface", style: { padding: 40, textAlign: "center", position: "relative", overflow: "hidden" } },
        React.createElement("svg", { viewBox: "0 0 200 120", style: { position: "absolute", inset: "auto -40px -20px auto", width: 280, color: "var(--brand-primary)", opacity: 0.06, pointerEvents: "none" }, fill: "currentColor" },
          React.createElement("path", { d: "M 20 80 C 60 20, 140 30, 180 70 C 130 65, 90 70, 60 95 C 50 90, 35 88, 20 80 Z" })
        ),
        React.createElement("div", { style: { fontSize: 16, fontWeight: 600, color: "var(--fg-1)" } }, t("هذا القسم لم يُرسم في الـ UI kit", "This screen isn't drawn in the UI kit")),
        React.createElement("div", { style: { fontSize: 13, color: "var(--fg-3)", marginTop: 8, maxWidth: 480, marginInline: "auto" } },
          t("اطّلع على الـ SRS لتفاصيل الوظائف. تواجه: الفريق · القوالب · الإعدادات.",
            "See the SRS for functional detail. Surfaces left out: Team · Templates · Settings."))
      )
    );
  };
  return React.createElement(Comp, null);
}

window.App = App;

ReactDOM.createRoot(document.getElementById("root")).render(
  React.createElement(AppProvider, null, React.createElement(App, null))
);
