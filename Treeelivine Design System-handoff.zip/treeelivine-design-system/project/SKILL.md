---
name: treeelivine-design
description: Use this skill to generate well-branded interfaces and assets for Treeelivine — an Arabic-first marketing-agency ERP with a client portal — either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI-kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

Treeelivine is a Saudi-market marketing-agency ERP + client portal. The brand is Arabic-first, bilingual (ar/en), uses a deep olive-green primary on warm sand surfaces, with full Light + Dark support. The system is dense, operational, and emphatically not consumer-y.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. Specifically:

- Always import the design tokens via `<link rel="stylesheet" href="colors_and_type.css">` and let the CSS variables drive every color, type, radius, and shadow choice. Do not invent new colors.
- Default to `dir="rtl"` and `lang="ar"`. Use logical CSS properties (`padding-inline`, `inset-inline-start`) so the same markup works LTR.
- For internal-operator screens, model the layout on `ui_kits/erp/` — fixed 248px sidebar + 56px topbar + scrollable content area.
- For customer-facing screens, model on `ui_kits/portal/` — top-nav shell + max-1180px content stack.
- Status pills, KPI tiles, tables, drawers, and avatars are defined in the preview cards under `preview/` — recreate from those patterns; don't roll new visual treatments.
- Icons come from Lucide via CDN. Do not draw your own SVG icons unless they're the brand mark itself.
- No emoji. No exclamation marks. No gradient blobs. No glassmorphism.

If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand. The token names in `colors_and_type.css` are the canonical identifiers — port them verbatim into any Tailwind config or design-token JSON.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (which product surface? what role? Arabic, English, or both? light or dark default?), and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
